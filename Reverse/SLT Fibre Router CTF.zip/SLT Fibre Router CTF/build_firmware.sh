#!/bin/bash
set -e

echo "========================================="
echo " SLT Fibre Router - Firmware Builder"
echo "========================================="
echo ""

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check for required tools
echo -e "${BLUE}[1/6]${NC} Checking dependencies..."
if ! command -v mksquashfs &> /dev/null; then
    echo "Error: mksquashfs not found. Install squashfs-tools:"
    echo "  sudo apt-get install squashfs-tools"
    exit 1
fi
echo -e "${GREEN}✓${NC} All dependencies found"

# Create firmware root structure
echo -e "${BLUE}[2/6]${NC} Creating firmware filesystem..."
mkdir -p firmware_root/{bin,etc/init.d,lib,sbin,usr/bin,usr/lib,var,tmp,dev,proc,sys}

# Copy the diagd binary
echo -e "${BLUE}[3/6]${NC} Installing diagnostic binary..."
cp diagd firmware_root/sbin/diagd
chmod +x firmware_root/sbin/diagd

# Create nvram.dat with the flag
echo -e "${BLUE}[4/6]${NC} Creating NVRAM data..."
echo "SLT{h1dd3n_d14gn0st1c_b4ckd00r_unl0ck3d}" > firmware_root/nvram.dat

# Create the hidden init script
echo -e "${BLUE}[5/6]${NC} Creating init scripts..."
cat > firmware_root/etc/init.d/S99diagd << 'EOF'
#!/bin/sh
# Hidden diagnostic interface launcher
# This script is executed on boot to start the diagnostic daemon

case "$1" in
    start)
        echo "Starting diagnostic interface..."
        /sbin/diagd &
        ;;
    stop)
        killall diagd 2>/dev/null
        ;;
    *)
        echo "Usage: $0 {start|stop}"
        exit 1
        ;;
esac

exit 0
EOF
chmod +x firmware_root/etc/init.d/S99diagd

# Create a basic rcS script
cat > firmware_root/etc/init.d/rcS << 'EOF'
#!/bin/sh
# System initialization script

# Mount virtual filesystems
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev

# Run all init scripts
for i in /etc/init.d/S??* ; do
    [ -x "$i" ] && $i start
done
EOF
chmod +x firmware_root/etc/init.d/rcS

# Create a fake passwd file for realism
cat > firmware_root/etc/passwd << 'EOF'
root:x:0:0:root:/root:/bin/sh
admin:x:1000:1000:Administrator:/home/admin:/bin/sh
EOF

# Create SquashFS image
echo -e "${BLUE}[6/6]${NC} Building SquashFS filesystem..."
mksquashfs firmware_root firmware.squashfs -comp xz -noappend -quiet

# Create firmware header (simulating U-Boot header)
# This is a simplified header for the challenge
cat > firmware_header.txt << 'EOF'
SLT FIBRE ROUTER FIRMWARE v2.1.0
Model: SLT-FIBER-X1
Build Date: 2024-11-15
Bootloader: U-Boot 2019.07
Kernel: Linux 4.14.98
Filesystem: SquashFS (XZ compressed)
---END HEADER---
EOF

# Combine header and SquashFS to create final firmware
cat firmware_header.txt firmware.squashfs > slt_fibre_rebrand_full_dump.bin

# Add some padding at the beginning to make it more realistic
# Real firmware often has bootloader code before the filesystem
dd if=/dev/zero bs=1024 count=256 2>/dev/null | cat - slt_fibre_rebrand_full_dump.bin > temp_firmware.bin
mv temp_firmware.bin slt_fibre_rebrand_full_dump.bin

# Clean up temporary files
rm -f firmware_header.txt firmware.squashfs

echo ""
echo -e "${GREEN}=========================================${NC}"
echo -e "${GREEN}✓ Firmware build complete!${NC}"
echo -e "${GREEN}=========================================${NC}"
echo ""
echo "Output: slt_fibre_rebrand_full_dump.bin"
echo "Size: $(du -h slt_fibre_rebrand_full_dump.bin | cut -f1)"
echo ""
echo "To verify:"
echo "  binwalk slt_fibre_rebrand_full_dump.bin"
echo ""
