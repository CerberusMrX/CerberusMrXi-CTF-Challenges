# SLT Fibre Router CTF Challenge - Deployment Guide

**For CTF Organizers**

---

## Overview

This document provides instructions for building and deploying the "SLT Fibre Router – Firmware Backdoor Analysis" CTF challenge.

## Prerequisites

### Required Tools

The build system requires the following tools to be installed:

```bash
# On Debian/Ubuntu/Kali Linux
sudo apt-get update
sudo apt-get install -y \
    build-essential \
    gcc \
    make \
    squashfs-tools \
    binwalk

# Verify installations
gcc --version
make --version
mksquashfs -version
binwalk --version
```

### System Requirements

- **OS**: Linux (Debian/Ubuntu/Kali recommended)
- **Disk Space**: ~10 MB for build artifacts
- **RAM**: Minimal (build process is lightweight)

---

## Building the Challenge

### Quick Build

From the challenge directory:

```bash
cd /path/to/slt-ctf
make all
```

This will:
1. Compile the `diagd` diagnostic binary (statically linked)
2. Build the `crc_finder` tool
3. Create the firmware filesystem structure
4. Package everything into `slt_fibre_rebrand_full_dump.bin`

### Step-by-Step Build

If you prefer to build components individually:

```bash
# 1. Build the diagnostic binary
make diagd

# 2. Build the CRC finder tool (optional, for testing)
make crc_finder

# 3. Create firmware filesystem structure
make firmware_root

# 4. Build the complete firmware image
make firmware
```

### Verify the Build

Check that the firmware was created successfully:

```bash
ls -lh slt_fibre_rebrand_full_dump.bin
```

Expected size: ~500-600 KB

Verify with binwalk:

```bash
binwalk slt_fibre_rebrand_full_dump.bin
```

Expected output:
```
DECIMAL       HEXADECIMAL     DESCRIPTION
--------------------------------------------------------------------------------
262323        0x400B3         Squashfs filesystem, little endian, version 4.0
```

---

## Testing the Challenge

### Test Password Authentication

Extract the firmware and test the diagnostic binary:

```bash
# Extract firmware
binwalk -e slt_fibre_rebrand_full_dump.bin
cd _slt_fibre_rebrand_full_dump.bin.extracted/squashfs-root

# Test with correct password
echo "slt_debug_admin" | ./sbin/diagd
```

Expected output:
```
==========================================
 SLT FIBRE ROUTER - DIAGNOSTIC INTERFACE  
      (INTERNAL USE ONLY - v2.1)          
==========================================

Login required.
User: admin (locked)
Enter Engineer Password: 
[SUCCESS] Access Granted. Engineer Mode Active.
NVRAM_CONF_FLAG: SLT{h1dd3n_d14gn0st1c_b4ckd00r_unl0ck3d}
```

### Test with Wrong Password

```bash
echo "wrong_password" | ./sbin/diagd
```

Expected output:
```
[ERROR] Invalid Checksum. Access Denied.
```

Note: No debug information should be displayed (removed for Hard difficulty).

---

## Deployment Options

### Option 1: Direct File Distribution

Simply provide players with the firmware file:

```
slt_fibre_rebrand_full_dump.bin
```

**Pros:**
- Simple and straightforward
- Players download and analyze locally
- No infrastructure needed

**Cons:**
- No interaction tracking
- Players could share the file

### Option 2: Web Download

Host the firmware on a web server:

```bash
# Example with Python HTTP server
python3 -m http.server 8000
```

Players download via:
```
http://your-server:8000/slt_fibre_rebrand_full_dump.bin
```

### Option 3: CTFd Integration

If using CTFd platform:

1. Create a new challenge
2. Set category: "Reverse Engineering" or "Firmware"
3. Set difficulty: "Hard"
4. Upload `slt_fibre_rebrand_full_dump.bin` as an attachment
5. Copy description from `README.md`
6. Set flag: `SLT{h1dd3n_d14gn0st1c_b4ckd00r_unl0ck3d}`
7. Add hints (optional):
   - Hint 1 (50 pts): "The filesystem is SquashFS. Try binwalk."
   - Hint 2 (100 pts): "Look for suspicious init scripts in /etc/init.d/"
   - Hint 3 (150 pts): "The password validation uses a custom CRC32 algorithm."

---

## Challenge Files

### Files to Distribute

**Required:**
- `slt_fibre_rebrand_full_dump.bin` - The firmware image

**Optional (for players):**
- `README.md` - Challenge description and hints

**For Organizers Only (DO NOT DISTRIBUTE):**
- `SOLUTION.md` - Complete solution walkthrough
- `src/diagd.c` - Source code of diagnostic binary
- `src/crc_finder.c` - CRC finder tool source
- `build_firmware.sh` - Build script
- `Makefile` - Build automation
- `DEPLOYMENT.md` - This file

### Directory Structure for Distribution

```
slt-fibre-ctf/
├── README.md                           # Challenge description
└── slt_fibre_rebrand_full_dump.bin    # Firmware image
```

---

## Customization

### Changing the Password

To use a different password:

1. Choose your password (e.g., "my_custom_pass")
2. Calculate its CRC:
   ```bash
   ./crc_finder "my_custom_pass"
   ```
3. Update `src/diagd.c`:
   ```c
   #define TARGET_CRC 0xYOUR_NEW_CRC
   ```
4. Rebuild:
   ```bash
   make clean
   make all
   ```

### Changing the Flag

Edit `build_firmware.sh` and modify line:

```bash
echo "SLT{your_new_flag_here}" > firmware_root/nvram.dat
```

Then rebuild:

```bash
make clean
make firmware
```

### Adjusting Difficulty

**To make it easier:**
- Add debug output back to `diagd.c` (show calculated CRC)
- Provide the CRC algorithm in hints
- Use a common password from wordlists

**To make it harder:**
- Strip the binary: `strip diagd`
- Use a longer, more complex password
- Add anti-debugging techniques
- Encrypt the NVRAM data

---

## Troubleshooting

### Build Errors

**Error: `mksquashfs: command not found`**

Solution:
```bash
sudo apt-get install squashfs-tools
```

**Error: `gcc: command not found`**

Solution:
```bash
sudo apt-get install build-essential
```

**Error: Static linking failed**

Some systems may not have static libraries. Try:
```bash
sudo apt-get install libc6-dev
```

Or modify `Makefile` to remove `-static` flag (but this makes the binary less portable).

### Runtime Errors

**Error: `nvram.dat` not found**

The `diagd` binary expects `nvram.dat` in the current directory. Make sure you're running it from the extracted firmware root.

**Error: Permission denied**

Make sure the binary is executable:
```bash
chmod +x sbin/diagd
```

---

## Clean Up

To remove all build artifacts:

```bash
make clean
```

This removes:
- Compiled binaries (`diagd`, `crc_finder`)
- Firmware filesystem (`firmware_root/`)
- SquashFS image
- Final firmware dump

---

## Support

For issues or questions about this challenge:

- **Author**: Sudeepa Wanigarathna
- **Challenge**: SLT Fibre Router – Firmware Backdoor Analysis
- **Category**: Reverse Engineering / Firmware
- **Difficulty**: Hard

---

## Security Notes

⚠️ **Important**: This challenge contains a deliberately vulnerable binary for educational purposes. Do not deploy the `diagd` binary on production systems or expose it to untrusted networks.

The custom CRC32 authentication is intentionally weak and should never be used in real security applications.

---

## License

This CTF challenge is provided for educational purposes. Feel free to use, modify, and distribute for CTF competitions and security training.

---

## Changelog

- **v1.0** (2024-12-02): Initial release
  - Custom CRC32 authentication
  - SquashFS firmware image
  - Complete solution walkthrough
  - Build automation with Makefile
