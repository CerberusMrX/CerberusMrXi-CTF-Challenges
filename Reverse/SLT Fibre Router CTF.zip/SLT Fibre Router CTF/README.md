# SLT Fibre Router – Firmware Backdoor Analysis

**Category:** Reverse Engineering / Firmware  
**Difficulty:** Hard  
**Author:** Sudeepa Wanigarathna  

## Description

A "rebranded" Sri Lankan SLT fibre router (Model: SLT-FIBER-X1) has been widely deployed in homes and small offices. Recently, a suspicious firmware update bricked a device belonging to a local security researcher. 

Suspecting foul play, the researcher managed to desolder the flash chip and recover a full firmware dump via SPI. Initial analysis suggests the firmware contains a hidden, engineer-only diagnostic interface that was never meant to be seen by the public.

Your mission, should you choose to accept it:
1.  Analyze the provided firmware dump (`slt_fibre_rebrand_full_dump.bin`).
2.  Locate the hidden diagnostic mechanism.
3.  Reverse engineer the authentication logic protecting it.
4.  Recover the engineer password and "log in" to retrieve the flag stored in the device's NVRAM.

**Provided Files:**
*   `slt_fibre_rebrand_full_dump.bin` (The firmware image)

## Hints
*   The filesystem seems to be standard SquashFS. `binwalk` might be useful.
*   Look for non-standard init scripts in `/etc`.
*   The authentication check isn't cryptographic, it's just a checksum.
*   The flag is stored in the simulated NVRAM.

## Goal
Find the flag in the format: `SLT{...}`
