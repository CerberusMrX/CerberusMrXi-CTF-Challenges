# SLT Fibre Router – Firmware Backdoor Analysis

**Complete CTF Challenge Package**

## Quick Start for Organizers

### Build the Challenge

```bash
make all
```

This creates `slt_fibre_rebrand_full_dump.bin` - the firmware image to distribute to players.

### Distribute to Players

Provide players with:
- `slt_fibre_rebrand_full_dump.bin`
- `README.md` (challenge description)

### Solution

- **Password**: `slt_debug_admin`
- **Flag**: `SLT{h1dd3n_d14gn0st1c_b4ckd00r_unl0ck3d}`
- **Full Walkthrough**: See `SOLUTION.md`

## Documentation

- **README.md** - Challenge description and hints (for players)
- **SOLUTION.md** - Complete solution walkthrough (for organizers)
- **DEPLOYMENT.md** - Build and deployment instructions (for organizers)

## Project Structure

```
slt-ctf/
├── README.md              # Challenge description
├── SOLUTION.md            # Solution walkthrough
├── DEPLOYMENT.md          # Deployment guide
├── ORGANIZER_NOTES.md     # This file
├── Makefile               # Build automation
├── build_firmware.sh      # Firmware build script
├── .gitignore            # Git ignore rules
├── src/
│   ├── diagd.c           # Diagnostic binary source
│   └── crc_finder.c      # CRC finder tool source
└── slt_fibre_rebrand_full_dump.bin  # Built firmware (after make)
```

## Challenge Details

- **Category**: Reverse Engineering / Firmware
- **Difficulty**: Hard
- **Skills Required**:
  - Firmware extraction (binwalk)
  - Filesystem analysis
  - Binary reverse engineering
  - CRC32 algorithm understanding
  - Password cracking/brute-forcing

## Testing

```bash
# Build everything
make all

# Extract and test
binwalk -e slt_fibre_rebrand_full_dump.bin
cd _slt_fibre_rebrand_full_dump.bin.extracted/squashfs-root
echo "slt_debug_admin" | ./sbin/diagd
```

Expected output: Flag should be displayed.

## Customization

See `DEPLOYMENT.md` for instructions on:
- Changing the password
- Changing the flag
- Adjusting difficulty

## Clean Up

```bash
make clean
```

Removes all build artifacts.

## Author

**Sudeepa Wanigarathna**

---

**Note**: Keep this file and `SOLUTION.md` confidential. Only distribute `README.md` and the firmware binary to players.
