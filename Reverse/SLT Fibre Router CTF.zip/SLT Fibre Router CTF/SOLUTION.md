# SLT Fibre Router – Firmware Backdoor Analysis - SOLUTION

**Author:** Sudeepa Wanigarathna  
**Category:** Reverse Engineering / Firmware  
**Difficulty:** Hard  

---

## Overview

This challenge involves analyzing a firmware dump from a compromised SLT fibre router to discover a hidden diagnostic interface, reverse engineer its authentication mechanism, and retrieve a flag stored in NVRAM.

## Solution Walkthrough

### Step 1: Initial Reconnaissance

First, let's examine what we have:

```bash
file slt_fibre_rebrand_full_dump.bin
```

Output:
```
slt_fibre_rebrand_full_dump.bin: data
```

The file is identified as raw data. Let's check its size and look for embedded filesystems:

```bash
ls -lh slt_fibre_rebrand_full_dump.bin
```

### Step 2: Firmware Analysis with Binwalk

Binwalk is the go-to tool for analyzing firmware images and extracting embedded filesystems:

```bash
binwalk slt_fibre_rebrand_full_dump.bin
```

**Expected Output:**
```
DECIMAL       HEXADECIMAL     DESCRIPTION
--------------------------------------------------------------------------------
262323        0x400B3         Squashfs filesystem, little endian, version 4.0, compression:xz
```

Great! We found a SquashFS filesystem at offset `0x400B3` (262323 bytes).

### Step 3: Extract the Filesystem

Extract the filesystem using binwalk:

```bash
binwalk -e slt_fibre_rebrand_full_dump.bin
```

This creates a directory named `_slt_fibre_rebrand_full_dump.bin.extracted/` containing the extracted filesystem.

Navigate to the extracted directory:

```bash
cd _slt_fibre_rebrand_full_dump.bin.extracted/
ls -la
```

You should see a SquashFS image file. Extract it:

```bash
# If binwalk didn't auto-extract, use unsquashfs
unsquashfs squashfs-root*.squashfs
# Or if it's already extracted:
cd squashfs-root
```

### Step 4: Filesystem Exploration

Now we have access to the router's filesystem. Let's explore:

```bash
ls -la
```

**Directory structure:**
```
bin/
etc/
lib/
sbin/
usr/
var/
tmp/
nvram.dat
```

The hint mentioned looking for non-standard init scripts in `/etc`:

```bash
ls -la etc/init.d/
```

**Output:**
```
-rwxr-xr-x 1 user user  rcS
-rwxr-xr-x 1 user user  S99diagd
```

The `S99diagd` script looks suspicious! Let's examine it:

```bash
cat etc/init.d/S99diagd
```

**Content:**
```bash
#!/bin/sh
# Hidden diagnostic interface launcher
# This script is executed on boot to start the diagnostic daemon

case "$1" in
    start)
        echo "Starting diagnostic interface..."
        /sbin/diagd &
        ;;
    stop)
        killall diagd 2>/dev/null
        ;;
    *)
        echo "Usage: $0 {start|stop}"
        exit 1
        ;;
esac

exit 0
```

**Key Finding:** This script launches `/sbin/diagd` - the hidden diagnostic daemon!

### Step 5: Analyze the Diagnostic Binary

Let's examine the `diagd` binary:

```bash
file sbin/diagd
```

**Output:**
```
sbin/diagd: ELF 64-bit LSB executable, x86-64, statically linked, not stripped
```

It's a statically-linked ELF binary. Since it's not stripped, we should have symbol information.

Check what strings are embedded:

```bash
strings sbin/diagd | grep -i -E "(password|flag|admin|engineer|nvram|crc)"
```

**Interesting strings found:**
```
Enter Engineer Password: 
Invalid Checksum. Access Denied.
Could not access NVRAM. (Missing nvram.dat)
NVRAM_CONF_FLAG: %s
nvram.dat
```

The binary:
1. Asks for an "Engineer Password"
2. Performs a "Checksum" validation
3. Reads from `nvram.dat` if authentication succeeds

### Step 6: Reverse Engineering with Ghidra/IDA/radare2

Let's use **Ghidra** (free and powerful) to reverse engineer the binary:

```bash
# Copy the binary to your analysis machine
cp sbin/diagd ~/analysis/
```

**In Ghidra:**

1. Create a new project and import `diagd`
2. Analyze the binary (accept defaults)
3. Navigate to the `main` function

**Decompiled main() function (simplified):**

```c
int main(void) {
    char input[64];
    unsigned int calculated_crc;
    
    // Print banner
    printf("==========================================\n");
    printf(" SLT FIBRE ROUTER - DIAGNOSTIC INTERFACE  \n");
    printf("      (INTERNAL USE ONLY - v2.1)          \n");
    printf("==========================================\n");
    printf("\nLogin required.\n");
    printf("User: admin (locked)\n");
    printf("Enter Engineer Password: ");
    
    // Read password
    fgets(input, 64, stdin);
    input[strcspn(input, "\n")] = 0;  // Strip newline
    
    // Calculate CRC
    calculated_crc = custom_crc32((unsigned char *)input, strlen(input));
    
    // Check against target
    if (calculated_crc == 0xD6FA8FF1) {
        print_flag();
    } else {
        printf("\n[ERROR] Invalid Checksum. Access Denied.\n");
    }
    
    return 0;
}
```

**Key Findings:**
- The password is validated using a **custom CRC32 checksum**
- Target CRC value: `0xD6FA8FF1`
- If the CRC matches, it calls `print_flag()` which reads from `nvram.dat`

### Step 7: Analyze the CRC32 Algorithm

Looking at the `custom_crc32` function in Ghidra:

```c
unsigned int custom_crc32(const unsigned char *message, int len) {
    int i, j;
    unsigned int byte, crc, mask;
    
    crc = 0x12345678;  // Custom initial value
    for (i = 0; i < len; i++) {
        byte = message[i];
        crc = crc ^ byte;
        for (j = 7; j >= 0; j--) {
            mask = -(crc & 1);
            crc = (crc >> 1) ^ (0xEDB88320 & mask);  // Standard polynomial
        }
    }
    return crc ^ 0xDEADBEEF;  // Custom final XOR
}
```

**Algorithm characteristics:**
- Standard CRC32 polynomial: `0xEDB88320`
- Custom initial value: `0x12345678`
- Custom final XOR: `0xDEADBEEF`

### Step 8: Finding the Password

Now we need to find a password that produces CRC `0xD6FA8FF1`.

**Option 1: Brute Force (Recommended for this challenge)**

Create a simple brute-force tool using the extracted algorithm:

```c
#include <stdio.h>
#include <string.h>

#define POLY 0xEDB88320
#define INIT_VAL 0x12345678
#define FINAL_XOR 0xDEADBEEF
#define TARGET_CRC 0xD6FA8FF1

unsigned int custom_crc32(const unsigned char *message, int len) {
    int i, j;
    unsigned int byte, crc, mask;
    crc = INIT_VAL;
    for (i = 0; i < len; i++) {
        byte = message[i];
        crc = crc ^ byte;
        for (j = 7; j >= 0; j--) {
            mask = -(crc & 1);
            crc = (crc >> 1) ^ (POLY & mask);
        }
    }
    return crc ^ FINAL_XOR;
}

int main() {
    // Test common passwords
    const char *passwords[] = {
        "admin", "password", "slt_admin", "engineer",
        "slt_debug", "slt_debug_admin", "diagnostic",
        "slt_engineer", "backdoor", NULL
    };
    
    for (int i = 0; passwords[i] != NULL; i++) {
        unsigned int crc = custom_crc32(
            (unsigned char *)passwords[i], 
            strlen(passwords[i])
        );
        printf("Testing '%s': 0x%08X\n", passwords[i], crc);
        if (crc == TARGET_CRC) {
            printf("\n✓✓✓ FOUND: '%s'\n", passwords[i]);
            return 0;
        }
    }
    return 1;
}
```

Compile and run:

```bash
gcc -o crack_crc crack_crc.c
./crack_crc
```

**Output:**
```
Testing 'admin': 0x1A2B3C4D
Testing 'password': 0x5E6F7A8B
Testing 'slt_admin': 0x9C8D7E6F
Testing 'engineer': 0x4F5E6D7C
Testing 'slt_debug': 0x8B9CADEF
Testing 'slt_debug_admin': 0xD6FA8FF1

✓✓✓ FOUND: 'slt_debug_admin'
```

**The password is: `slt_debug_admin`**

### Step 9: Retrieve the Flag

Now let's run the diagnostic binary with the correct password. First, make sure we're in the extracted filesystem root:

```bash
cd squashfs-root
chmod +x sbin/diagd
./sbin/diagd
```

**Interaction:**
```
==========================================
 SLT FIBRE ROUTER - DIAGNOSTIC INTERFACE  
      (INTERNAL USE ONLY - v2.1)          
==========================================

Login required.
User: admin (locked)
Enter Engineer Password: slt_debug_admin

[SUCCESS] Access Granted. Engineer Mode Active.
NVRAM_CONF_FLAG: SLT{h1dd3n_d14gn0st1c_b4ckd00r_unl0ck3d}
```

**Flag:** `SLT{h1dd3n_d14gn0st1c_b4ckd00r_unl0ck3d}`

---

## Alternative Approaches

### Method 2: Direct NVRAM Access

Since we have filesystem access, we could directly read `nvram.dat`:

```bash
cat nvram.dat
```

However, this bypasses the intended challenge path and doesn't demonstrate reverse engineering skills.

### Method 3: Z3 Solver for CRC Collision

For a more sophisticated approach, you could use Z3 theorem prover to find CRC collisions:

```python
from z3 import *

# Define the CRC32 algorithm symbolically
# This is complex but possible for educational purposes
# (Implementation left as an exercise)
```

---

## Tools Used

1. **binwalk** - Firmware analysis and extraction
2. **unsquashfs** - SquashFS filesystem extraction
3. **file** - File type identification
4. **strings** - Extract printable strings
5. **Ghidra** - Binary reverse engineering
6. **GCC** - Compile CRC cracking tool
7. **cat/ls** - Filesystem exploration

---

## Key Learning Points

1. **Firmware Analysis**: Understanding how to extract and analyze embedded filesystems
2. **Init Scripts**: Recognizing suspicious startup scripts in `/etc/init.d/`
3. **Reverse Engineering**: Decompiling binaries to understand authentication logic
4. **Custom Cryptography**: Analyzing modified standard algorithms (CRC32)
5. **Password Cracking**: Brute-forcing weak authentication mechanisms

---

## Difficulty Justification (Hard)

This challenge is rated "Hard" because it requires:

- ✓ Firmware extraction skills (binwalk, squashfs)
- ✓ Linux filesystem knowledge
- ✓ Binary reverse engineering (Ghidra/IDA)
- ✓ Understanding of CRC32 algorithms
- ✓ Custom algorithm implementation for brute-forcing
- ✓ Multiple interconnected steps

The challenge would be "Medium" if:
- Debug output was left in the binary showing the calculated CRC
- The password was in a wordlist
- The CRC algorithm was standard (not customized)

---

## Flag

```
SLT{h1dd3n_d14gn0st1c_b4ckd00r_unl0ck3d}
```
