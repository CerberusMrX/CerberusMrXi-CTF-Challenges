#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Same CRC32 implementation as diagd.c
#define POLY 0xEDB88320
#define INIT_VAL 0x12345678
#define FINAL_XOR 0xDEADBEEF

unsigned int custom_crc32(const unsigned char *message, int len) {
    int i, j;
    unsigned int byte, crc, mask;

    crc = INIT_VAL;
    for (i = 0; i < len; i++) {
        byte = message[i];
        crc = crc ^ byte;
        for (j = 7; j >= 0; j--) {
            mask = -(crc & 1);
            crc = (crc >> 1) ^ (POLY & mask);
        }
    }
    return crc ^ FINAL_XOR;
}

void test_password(const char *password, unsigned int target) {
    unsigned int crc = custom_crc32((unsigned char *)password, strlen(password));
    printf("Password: '%s'\n", password);
    printf("CRC32:    0x%08X\n", crc);
    if (crc == target) {
        printf("✓ MATCH! This is the correct password!\n");
    } else {
        printf("✗ No match (target: 0x%08X)\n", target);
    }
    printf("\n");
}

int main(int argc, char *argv[]) {
    unsigned int target_crc = 0xD6FA8FF1;  // Updated to match diagd.c
    
    printf("===========================================\n");
    printf(" SLT CTF - CRC32 Password Finder/Verifier \n");
    printf("===========================================\n");
    printf("Target CRC: 0x%08X\n\n", target_crc);

    if (argc > 1) {
        // Test provided password
        test_password(argv[1], target_crc);
        return 0;
    }

    // Test common thematic passwords
    printf("Testing thematic passwords...\n\n");
    
    const char *candidates[] = {
        "slt_debug_admin",
        "slt_engineer",
        "slt_backdoor",
        "slt_diagnostic",
        "slt_fibre_debug",
        "slt_admin_2024",
        "engineer_mode",
        "debug_access",
        "fiber_admin",
        "slt_tech_support",
        "slt_internal",
        "router_debug",
        "slt_service",
        "admin_diagnostic",
        "slt_firmware",
        "hidden_access",
        "slt_maintenance",
        "engineer_access",
        "slt_router_admin",
        "diagnostic_mode",
        NULL
    };

    int found = 0;
    for (int i = 0; candidates[i] != NULL; i++) {
        unsigned int crc = custom_crc32((unsigned char *)candidates[i], strlen(candidates[i]));
        if (crc == target_crc) {
            printf("✓✓✓ FOUND MATCH! ✓✓✓\n");
            printf("Password: '%s'\n", candidates[i]);
            printf("CRC32:    0x%08X\n\n", crc);
            found = 1;
            break;
        }
    }

    if (!found) {
        printf("No match found in predefined list.\n");
        printf("Trying brute force with variations...\n\n");
        
        // Try some variations with numbers
        char buffer[64];
        for (int year = 2020; year <= 2025; year++) {
            snprintf(buffer, sizeof(buffer), "slt_admin_%d", year);
            unsigned int crc = custom_crc32((unsigned char *)buffer, strlen(buffer));
            if (crc == target_crc) {
                printf("✓✓✓ FOUND MATCH! ✓✓✓\n");
                printf("Password: '%s'\n", buffer);
                printf("CRC32:    0x%08X\n\n", crc);
                found = 1;
                break;
            }
        }
    }

    if (!found) {
        printf("\nNo collision found. Recommendations:\n");
        printf("1. Choose a thematic password and calculate its CRC\n");
        printf("2. Update TARGET_CRC in diagd.c to match\n");
        printf("\nExample: ./crc_finder \"your_password_here\"\n");
    }

    return 0;
}
