#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

// Custom CRC32 Implementation
// Polynomial: 0xEDB88320 (Standard Ethernet/ZIP reversed)
// Initial Value: 0x12345678 (Custom)
// Final XOR: 0xDEADBEEF (Custom)

#define POLY 0xEDB88320
#define INIT_VAL 0x12345678
#define FINAL_XOR 0xDEADBEEF

unsigned int custom_crc32(const unsigned char *message, int len) {
    int i, j;
    unsigned int byte, crc, mask;

    crc = INIT_VAL;
    for (i = 0; i < len; i++) {
        byte = message[i];
        crc = crc ^ byte;
        for (j = 7; j >= 0; j--) {
            mask = -(crc & 1);
            crc = (crc >> 1) ^ (POLY & mask);
        }
    }
    return crc ^ FINAL_XOR;
}

// Target Hash for the correct password: "slt_debug_admin"
// CRC32 calculated with custom algorithm (INIT: 0x12345678, XOR: 0xDEADBEEF)
#define TARGET_CRC 0xD6FA8FF1 

void print_flag() {
    FILE *f = fopen("nvram.dat", "r");
    if (!f) {
        printf("Error: Could not access NVRAM. (Missing nvram.dat)\n");
        return;
    }
    char flag[128];
    if (fgets(flag, sizeof(flag), f)) {
        printf("\n[SUCCESS] Access Granted. Engineer Mode Active.\n");
        printf("NVRAM_CONF_FLAG: %s\n", flag);
    } else {
        printf("Error: NVRAM empty.\n");
    }
    fclose(f);
}

int main() {
    char input[64];
    unsigned int calculated_crc;

    // Disable buffering for UART simulation
    setvbuf(stdout, NULL, _IONBF, 0);

    printf("==========================================\n");
    printf(" SLT FIBRE ROUTER - DIAGNOSTIC INTERFACE  \n");
    printf("      (INTERNAL USE ONLY - v2.1)          \n");
    printf("==========================================\n");
    printf("\n");
    printf("Login required.\n");
    printf("User: admin (locked)\n");
    printf("Enter Engineer Password: ");

    if (fgets(input, sizeof(input), stdin) == NULL) {
        return 0;
    }

    // Strip newline
    input[strcspn(input, "\n")] = 0;

    // Calculate CRC
    calculated_crc = custom_crc32((unsigned char *)input, strlen(input));

    // Obfuscation note: In a real RE challenge, these constants would be hidden 
    // or the check would be: if ((crc ^ 0x1234) == 0x5678) ...
    
    if (calculated_crc == TARGET_CRC) {
        print_flag();
    } else {
        printf("\n[ERROR] Invalid Checksum. Access Denied.\n");
        // Debug output removed for Hard difficulty
    }

    return 0;
}
