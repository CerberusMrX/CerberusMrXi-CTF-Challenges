GOVPAY SECURITY UPDATE - CTF CHALLENGE
======================================

CHALLENGE OVERVIEW
------------------
Title: GovPay Security Update
Category: Reverse Engineering
Difficulty: Medium
Author: Sudeepa Wanigarathna

STORY
-----
In February 2025, Sri Lanka launched GovPay, a new digital platform for paying government fees and traffic fines online. A few weeks later, a "mandatory security update" started spreading on social media and WhatsApp, telling citizens to install a Windows app or risk account suspension.

Several victims noticed strange Rs. 1.00 test payments on their accounts and reported the incident. You are hired by a local infosec team to analyze the suspicious binary, GovPaySecurityUpdate.exe.

YOUR MISSION
------------
Your task is to reverse engineer the sample, find out how it hides its secret merchant code, and submit it as the flag.

Flag Format: flag{MERCHANT_CODE_HERE}

FILES INCLUDED
--------------
- GovPaySecurityUpdate.exe

BUILD INSTRUCTIONS
------------------
To compile the challenge binary, you can use MinGW on Linux or MSVC on Windows.

Option 1: Linux (MinGW)
Requires mingw-w64.

Command:
x86_64-w64-mingw32-gcc GovPaySecurityUpdate.c -o GovPaySecurityUpdate.exe -s

(Note: The -s flag strips symbols. The code uses stack strings and dynamic API resolution to hide imports.)

Option 2: Windows (MSVC)
Open the Developer Command Prompt for VS.

Command:
cl GovPaySecurityUpdate.c /Fe:GovPaySecurityUpdate.exe

NOTES FOR PLAYERS
-----------------
- Difficulty: Medium.
- Anti-Analysis: The binary contains basic anti-debugging and obfuscation techniques.
- Goal: Recover the merchant code.
- Safe to Run: The binary only writes a local log file (gp_update.log).
