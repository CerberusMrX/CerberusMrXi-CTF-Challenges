#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// ---------------------------------------------------------------------
// GovPay Security Update
// "Mandatory Security Patch" - February 2025
// ---------------------------------------------------------------------

// Fake flag to distract simple strings analysis
const char* g_decoy = "flag{fake_flag_try_harder_next_time}";

// Obfuscated Key (XORed with 0x55)
// Real Key: 0xDE, 0xAD, 0xBE, 0xEF
unsigned char g_k[] = { 0x8B, 0xF8, 0xEB, 0xBA };

// Encrypted Merchant Code
// Plaintext: CERBERUS_MRXI_MERCHANT_01
unsigned char g_enc_data[] = {
    0x9D, 0xE8, 0xEC, 0xAD, 0x9B, 0xFF, 0xEB, 0xBC, 
    0x81, 0xE0, 0xEC, 0xB7, 0x97, 0xF2, 0xF3, 0xAA, 
    0x8C, 0xEE, 0xF6, 0xAE, 0x90, 0xF9, 0xE1, 0xDF, 
    0xEF
};

// Function pointers
typedef BOOL (WINAPI *PWRITEFILE)(HANDLE, LPCVOID, DWORD, LPDWORD, LPOVERLAPPED);
typedef HANDLE (WINAPI *PCREATEFILEA)(LPCSTR, DWORD, DWORD, LPSECURITY_ATTRIBUTES, DWORD, DWORD, HANDLE);
typedef VOID (WINAPI *PSLEEP)(DWORD);
typedef BOOL (WINAPI *PCLOSEHANDLE)(HANDLE);

// Helper to construct strings on stack to hide from 'strings' command
void get_str_kernel32(char* s) {
    // "kernel32.dll"
    s[0]='k'; s[1]='e'; s[2]='r'; s[3]='n'; s[4]='e'; s[5]='l'; s[6]='3'; s[7]='2'; s[8]='.'; s[9]='d'; s[10]='l'; s[11]='l'; s[12]=0;
}

void get_str_writefile(char* s) {
    // "WriteFile"
    s[0]='W'; s[1]='r'; s[2]='i'; s[3]='t'; s[4]='e'; s[5]='F'; s[6]='i'; s[7]='l'; s[8]='e'; s[9]=0;
}

void get_str_createfile(char* s) {
    // "CreateFileA"
    s[0]='C'; s[1]='r'; s[2]='e'; s[3]='a'; s[4]='t'; s[5]='e'; s[6]='F'; s[7]='i'; s[8]='l'; s[9]='e'; s[10]='A'; s[11]=0;
}

void get_str_sleep(char* s) {
    // "Sleep"
    s[0]='S'; s[1]='l'; s[2]='e'; s[3]='e'; s[4]='p'; s[5]=0;
}

void get_str_closehandle(char* s) {
    // "CloseHandle"
    s[0]='C'; s[1]='l'; s[2]='o'; s[3]='s'; s[4]='e'; s[5]='H'; s[6]='a'; s[7]='n'; s[8]='d'; s[9]='l'; s[10]='e'; s[11]=0;
}

void PerformSecurityCheck() {
    char s_k32[16]; get_str_kernel32(s_k32);
    char s_slp[8]; get_str_sleep(s_slp);
    
    HMODULE hK32 = GetModuleHandleA(s_k32);
    PSLEEP pSleep = (PSLEEP)GetProcAddress(hK32, s_slp);
    
    if(pSleep) {
        printf("[*] Verifying system integrity...\n");
        pSleep(1000);
        printf("[*] Checking for outdated certificates...\n");
        pSleep(1500);
    }
}

void DecryptMerchantConfig(char* buffer, size_t len) {
    unsigned char key[4];
    
    // Anti-Debug: If debugger is present, corrupt the key
    // This makes dynamic analysis fail silently if they don't bypass this
    if (IsDebuggerPresent()) {
        g_k[0] ^= 0xFF; // Corrupt the first byte of the source key
    }

    // De-obfuscate the key
    for(int i=0; i<4; i++) {
        key[i] = g_k[i] ^ 0x55;
    }

    // Decrypt the merchant code
    for(size_t i=0; i<len; i++) {
        buffer[i] = g_enc_data[i] ^ key[i % 4];
    }
    buffer[len] = '\0';
}

void LogTransaction(const char* merchantCode) {
    char s_k32[16]; get_str_kernel32(s_k32);
    char s_wf[16]; get_str_writefile(s_wf);
    char s_cf[16]; get_str_createfile(s_cf);
    char s_ch[16]; get_str_closehandle(s_ch);

    HMODULE hK32 = GetModuleHandleA(s_k32);
    PWRITEFILE pWriteFile = (PWRITEFILE)GetProcAddress(hK32, s_wf);
    PCREATEFILEA pCreateFileA = (PCREATEFILEA)GetProcAddress(hK32, s_cf);
    PCLOSEHANDLE pCloseHandle = (PCLOSEHANDLE)GetProcAddress(hK32, s_ch);

    if (!pWriteFile || !pCreateFileA || !pCloseHandle) return;

    HANDLE hFile = pCreateFileA("gp_update.log", FILE_APPEND_DATA, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    
    if (hFile == INVALID_HANDLE_VALUE) return;

    char logBuffer[256];
    DWORD bytesWritten;
    
    srand(time(NULL));
    int accId = rand() % 90000000 + 10000000;
    
    // Fake encrypted blob for the log
    sprintf(logBuffer, "TEST_PAYMENT|ACC:%d|MERCHANT:ENC(7F3A9B2C1D...)\r\n", accId);
    
    pWriteFile(hFile, logBuffer, strlen(logBuffer), &bytesWritten, NULL);
    
    pCloseHandle(hFile);
}

int main() {
    printf("GovPay Security Update Tool v1.0.4\n");
    printf("Copyright (C) 2025 GovPay Sri Lanka\n\n");

    PerformSecurityCheck();

    char merchantCode[64];
    memset(merchantCode, 0, sizeof(merchantCode));
    
    // Decrypt
    DecryptMerchantConfig(merchantCode, sizeof(g_enc_data));

    // Log
    LogTransaction(merchantCode);

    printf("\n[!] Error: Security Patch failed (Error Code: 0x80070005)\n");
    printf("[!] Please download the official installer again or contact support.\n");
    
    // Clear memory
    memset(merchantCode, 0, sizeof(merchantCode));
    
    return 1;
}
