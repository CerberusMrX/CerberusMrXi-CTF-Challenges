PROJECT ANTIGRAVITY: EVENT HORIZON
A Hardcore Cryptography Challenge by Sudeepa Wanigarathna

CATEGORY: Cryptography
DIFFICULTY: Hard
ESTIMATED TIME: 45 to 90 minutes

THE MISSION BRIEFING

Date: November 14, 2047
Location: The Singularity, 200m above sea level

The situation has escalated. The SkyForge facility hasn't just vanished; it has collapsed into a localized gravity well. The "Gravitational Attractor" drive is malfunctioning, creating a time-dilation field that is freezing entropy itself.

We have recovered the "Blackbox" flight recorder from a drone that barely escaped the event horizon. The data is locked behind the standard protocol, but the internal logs reveal a catastrophic failure in the drive's authentication system.

The drive uses an Elliptic Curve signature scheme to validate commands from the Core. However, due to the intense time dilation, the quantum entropy source used for random number generation appears to have "frozen". Every command sent during the incident seems to have been signed with the exact same temporal state.

Your mission is to exploit this entropy failure. Recover the Admin Private Key from the signature logs, decrypt the Core Dump, and retrieve the shutdown code before the singularity consumes the facility.

CHALLENGE FILES

You will provide the players with a single file: blackbox_recorder.enc

To generate this file and the internal flag, run the provided generate_challenge.py script.

Generation Command:
python3 generate_challenge.py

(Note: Requires pycryptodome library)

SOLUTION WALKTHROUGH

Step 1: Decrypt the Archive

The briefing clues remain consistent for the entry point.
Project Codename: SkyForge
Standard Gravity: 9.81
Password: SkyForge9.81

Command:
openssl enc -d -aes-256-cbc -pbkdf2 -in blackbox_recorder.enc -out blackbox.tar -k SkyForge9.81

Extract the contents:
tar -xf blackbox.tar

This reveals:
1. trace_logs.json (Contains two signed messages with identical 'r' values)
2. core_dump.bin (The flag, encrypted with the Private Key)
3. README.txt (Flavor text hinting at "Frozen Entropy")

Step 2: Identify the Vulnerability (ECDSA Nonce Reuse)

The player must inspect `trace_logs.json`. They will see two different messages (msg1, msg2) and their signatures (r1, s1) and (r2, s2).
Crucially, they will notice that r1 equals r2.

In ECDSA, the value 'r' is derived from the random nonce 'k'. If 'r' is the same for two different messages, it means the nonce 'k' was reused. This is a fatal flaw (famous for the PS3 hack).

Step 3: The Math (Recovering the Key)

Let z1 and z2 be the hashes of the messages.
Let s1 and s2 be the signature components.
Let k be the reused nonce.
Let d be the private key.
Let n be the order of the curve (SECP256k1).

The equations are:
s1 = k^-1 * (z1 + r * d)  mod n
s2 = k^-1 * (z2 + r * d)  mod n

Subtracting the two equations allows us to solve for k:
k = (z1 - z2) * (s1 - s2)^-1  mod n

Once k is found, we can solve for the private key d:
d = (s1 * k - z1) * r^-1  mod n

Step 4: Decrypt the Flag

The challenge description implies the Private Key is the key to the `core_dump.bin`.
Usually, this means the AES key is the SHA256 hash of the private key (in integer or bytes format).
The solver script will compute d, hash it, and decrypt the flag.

Run the solver:
python3 solve.py

Output:
[+] Detected Nonce Reuse!
[+] Recovered Private Key: 9284...
[SUCCESS] Flag: CTF{Ev3nt_H0r1z0n_Br0k3n_Entr0py_D3ad_K3y}

PROGRESSIVE HINTS

Hint 1
The gravity field has frozen time, and with it, the random number generator. Check the signatures in the log file. Do you see any repeating patterns where there should be chaos?

Hint 2
In Elliptic Curve cryptography, the value 'r' represents the x-coordinate of the random point. If two different messages share the same 'r', the system has committed the cardinal sin of Nonce Reuse.

Hint 3
Look up the "PS3 ECDSA Hack" or "ECDSA Nonce Reuse Attack". You have two equations with two unknowns (k and d). You can solve for k first, then derive the private key.

WHY THIS IS HARD DIFFICULTY

Mathematical Complexity
Unlike the Medium version (which used a simple square root), this requires understanding the algebra of ECDSA. The player must derive or find the formula for nonce recovery.

Vulnerability Identification
The flaw isn't explicitly stated as "Weak RSA". The player must look at the JSON, spot the duplicate 'r' value, and understand its implication.

Custom Implementation
There are fewer "one-click" tools for this specific scenario compared to RSA. The player likely needs to write a script to perform the modular arithmetic on the curve order.
