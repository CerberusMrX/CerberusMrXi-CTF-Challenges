import os
import json
import hashlib
import subprocess
from Crypto.PublicKey import ECC
from Crypto.Signature import DSS
from Crypto.Hash import SHA256
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from Crypto.Util.number import long_to_bytes

def generate_challenge():
    print("[*] Initiating SkyForge (HARD) Challenge Generation...")

    # --- STEP 1: Generate ECDSA Key (SECP256k1) ---
    print("[*] Generating Admin ECC Keys...")
    key = ECC.generate(curve='P-256') # Using NIST P-256 (standard)
    
    # NIST P-256 Curve Parameters (Hardcoded to avoid introspection errors)
    # n is the order of the curve
    n = 0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551
    
    # G is the generator point (we need this for manual signing)
    Gx = 0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296
    Gy = 0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5
    G = ECC.EccPoint(Gx, Gy, curve='P-256')

    d = int(key.d) # Private Key

    # --- STEP 2: Simulate Nonce Reuse (The Vulnerability) ---
    print("[*] Simulating Quantum Entropy Freeze (Nonce Reuse)...")
    
    # We manually sign to force a fixed 'k' (nonce)
    # k must be 1 < k < n-1
    # We pick a static k for the "frozen" state
    fixed_k = 13371337133713371337133713371337
    
    msg1 = b"COMMAND: INIT_STABILIZERS | STATUS: CRITICAL"
    msg2 = b"COMMAND: ADJUST_FLUX_CAPACITOR | LEVEL: MAX"
    
    # Helper to sign with fixed k
    def sign_with_fixed_k(message, priv_key, k, G, n):
        h = SHA256.new(message)
        z = int.from_bytes(h.digest(), 'big')
        
        d = int(priv_key.d)
        
        # Calculate r = (k * G).x mod n
        P = k * G
        r = int(P.x) % n
        
        # Calculate s = k^-1 * (z + r * d) mod n
        k_inv = pow(k, -1, n)
        s = (k_inv * (z + r * d)) % n
        
        return (r, s)

    r1, s1 = sign_with_fixed_k(msg1, key, fixed_k, G, n)
    r2, s2 = sign_with_fixed_k(msg2, key, fixed_k, G, n)
    
    print(f"    [DEBUG] r1: {r1}")
    print(f"    [DEBUG] r2: {r2}")
    if r1 == r2:
        print("    [+] Vulnerability Successfully Injected: r1 == r2")

    # Save the trace logs
    logs = {
        "curve": "NIST P-256",
        "logs": [
            {
                "message": msg1.decode(),
                "signature": {"r": hex(r1), "s": hex(s1)}
            },
            {
                "message": msg2.decode(),
                "signature": {"r": hex(r2), "s": hex(s2)}
            }
        ]
    }
    
    with open("trace_logs.json", "w") as f:
        json.dump(logs, f, indent=4)

    # --- STEP 3: Encrypt the Flag with the Private Key ---
    # We use the Private Key 'd' to derive an AES key.
    # AES Key = SHA256(d)
    print("[*] Encrypting Core Dump with Private Key...")
    
    flag = b"CTF{Ev3nt_H0r1z0n_Br0k3n_Entr0py_D3ad_K3y}"
    
    # Convert d to bytes and hash it to get a 32-byte AES key
    aes_key = SHA256.new(long_to_bytes(d)).digest()
    cipher = AES.new(aes_key, AES.MODE_GCM)
    ciphertext, tag = cipher.encrypt_and_digest(flag)
    
    with open("core_dump.bin", "wb") as f:
        # We need to save the nonce for GCM decryption
        f.write(cipher.nonce + tag + ciphertext)

    # --- STEP 4: Flavor Text ---
    with open("README.txt", "w") as f:
        f.write("CRITICAL ALERT: ENTROPY FAILURE.\n")
        f.write("Quantum Stabilizers are stuck in a loop.\n")
        f.write("All commands are being signed with static temporal coordinates.\n")

    # --- STEP 5: Package and Encrypt ---
    password = "SkyForge9.81"
    print("[*] Packaging artifact...")
    
    subprocess.run(["tar", "-cf", "blackbox.tar", "trace_logs.json", "core_dump.bin", "README.txt"])
    
    subprocess.run([
        "openssl", "enc", "-aes-256-cbc", "-salt", "-pbkdf2", 
        "-in", "blackbox.tar", 
        "-out", "blackbox_recorder.enc", 
        "-k", password
    ])
    
    # Cleanup
    os.remove("blackbox.tar")
    os.remove("trace_logs.json")
    os.remove("core_dump.bin")
    os.remove("README.txt")
    
    print(f"\n[SUCCESS] Challenge generated: 'blackbox_recorder.enc'")

if __name__ == "__main__":
    generate_challenge()
