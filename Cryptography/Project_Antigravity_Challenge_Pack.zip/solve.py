import json
import hashlib
from Crypto.Hash import SHA256
from Crypto.PublicKey import ECC
from Crypto.Cipher import AES
from Crypto.Util.number import long_to_bytes, inverse

# --- Step 1: Load the Logs ---
try:
    with open("trace_logs.json", "r") as f:
        data = json.load(f)
except FileNotFoundError:
    print("[-] trace_logs.json not found. Decrypt the archive first!")
    exit(1)

print("[*] Analyzing Trace Logs...")

# Extract messages and signatures
log1 = data["logs"][0]
log2 = data["logs"][1]

msg1 = log1["message"].encode()
msg2 = log2["message"].encode()

r1 = int(log1["signature"]["r"], 16)
s1 = int(log1["signature"]["s"], 16)

r2 = int(log2["signature"]["r"], 16)
s2 = int(log2["signature"]["s"], 16)

# --- Step 2: Detect Vulnerability ---
if r1 == r2:
    print("[+] VULNERABILITY DETECTED: Nonce Reuse (r1 == r2)")
    print(f"    Reused r: {hex(r1)}")
else:
    print("[-] No nonce reuse detected. Exiting.")
    exit(1)

# --- Step 3: Recover the Private Key ---
print("[*] Attempting to recover Private Key...")

# Curve Parameters for NIST P-256
# We can get these from the Crypto library or hardcode them
# P-256 Order (n)
n = 0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551

# Calculate message hashes (z)
# Note: In ECDSA, z is the integer representation of the hash (truncated to bit length of n)
z1 = int.from_bytes(SHA256.new(msg1).digest(), 'big')
z2 = int.from_bytes(SHA256.new(msg2).digest(), 'big')

# Formula for k (nonce):
# k = (z1 - z2) * (s1 - s2)^-1 mod n
numerator = (z1 - z2) % n
denominator = inverse((s1 - s2), n)
k = (numerator * denominator) % n

print(f"[+] Recovered Nonce k: {k}")

# Formula for d (private key):
# s = k^-1 * (z + r*d)
# s*k = z + r*d
# s*k - z = r*d
# d = (s*k - z) * r^-1
r_inv = inverse(r1, n)
d = ((s1 * k - z1) * r_inv) % n

print(f"[+] Recovered Private Key d: {d}")

# --- Step 4: Decrypt the Flag ---
print("[*] Decrypting Core Dump...")

try:
    with open("core_dump.bin", "rb") as f:
        encrypted_data = f.read()
except FileNotFoundError:
    print("[-] core_dump.bin not found.")
    exit(1)

# Extract nonce, tag, ciphertext
# GCM nonce is usually 16 bytes
nonce = encrypted_data[:16]
tag = encrypted_data[16:32]
ciphertext = encrypted_data[32:]

# Derive AES key from Private Key d
aes_key = SHA256.new(long_to_bytes(d)).digest()

cipher = AES.new(aes_key, AES.MODE_GCM, nonce=nonce)

try:
    flag = cipher.decrypt_and_verify(ciphertext, tag)
    print(f"\n[SUCCESS] Flag: {flag.decode()}")
except ValueError:
    print("\n[-] Decryption failed. Key incorrect or data corrupted.")
