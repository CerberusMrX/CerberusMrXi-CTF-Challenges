Lost Transmission — Enhanced (player hints)

Files:
 - transmission.txt  (base64)
 - signal.png        (the signal image; has hidden metadata and extra data appended)
 - message2.txt      (Vigenere ciphertext)

Hints (low-spoiler):
1) base64 -d transmission.txt
2) Inspect signal.png's contents for hidden metadata (use 'strings', 'pngcheck', or 'exiftool')
   The Vigenere key is ROT13'd inside a tEXt chunk.
3) Decrypt message2.txt with the discovered key (Vigenere A-Z only).
4) message2.txt tells you the XOR key (multi-byte) and that the payload is appended
   to signal.png after IEND. Use 'binwalk' or extract bytes after the PNG IEND marker.
5) XOR the extracted bytes with the 4-byte key DE AD BE EF repeating and then 'gunzip' the result.

Good luck!
