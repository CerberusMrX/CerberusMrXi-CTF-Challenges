LankaSecure Bank - Messaging Portal CTF Challenge
===================================================

Challenge Overview
------------------
This is a medium-difficulty web exploitation challenge designed for CTF events.
Theme: Internal messaging portal for LankaSecure Bank support staff.
Objective: Exploit web vulnerabilities to retrieve two hidden flags.

Vulnerabilities:
1. Reflected Cross-Site Scripting (XSS)
2. Server-Side Template Injection (SSTI)

Installation & Running
----------------------

Option 1: Using Docker (Recommended)
1. Navigate to the LankaSecure directory:
   cd LankaSecure

2. Build the Docker image:
   docker build -t lankasecure .

3. Run the container:
   docker run -p 5001:5001 lankasecure

4. Access the application at:
   http://localhost:5001

Option 2: Running Locally (Python)
1. Ensure you have Python 3 and pip installed.

2. Install Flask:
   pip install flask

3. Run the application:
   python3 LankaSecure/app.py

4. Access the application at:
   http://localhost:5001

Writeup / Solution
------------------
A detailed step-by-step writeup is available in the `writeup/` directory.
Open `writeup/index.html` in your web browser to view the solution guide.

Credits
-------
Designed by Sudeepa Wanigarathna for LankaSecure CTF.
