import os
from flask import Flask, request, render_template, render_template_string, make_response

app = Flask(__name__)

# Configuration
# In a real scenario, these might be loaded from a config file or env vars
APP_NAME = "LankaSecure Bank - Internal Messaging Portal"
FLAG_XSS = "Flag{lanka_bank_xss_message}"
FLAG_SSTI = "Flag{colombo_bank_ssti_template}"

@app.route('/')
def index():
    """Landing page for the internal portal."""
    return render_template('index.html', title="Home")

@app.route('/message/search', methods=['GET'])
def message_search():
    """
    Search for customer messages.
    The 'q' parameter is used to filter results.
    """
    query = request.args.get('q', '')
    
    # Mock search results (static for this challenge)
    results = []
    if query:
        results = [
            {"id": 1024, "subject": "Account Access Issue", "sender": "nimal.perera@example.com", "date": "2023-10-25"},
            {"id": 1025, "subject": "Credit Card Inquiry", "sender": "sara.silva@example.com", "date": "2023-10-26"},
            {"id": 1028, "subject": "Loan Application Status", "sender": "kamal.fernando@example.com", "date": "2023-10-27"},
        ]

    # Check for the specific marker to release the first flag
    # This simulates an internal check or a hidden admin feature
    reveal_flag = False
    if 'xss-bank-check' in query:
        reveal_flag = True

    return render_template('search.html', 
                           title="Message Search", 
                           query=query, 
                           results=results, 
                           reveal_flag=reveal_flag,
                           secret_flag=FLAG_XSS)

@app.route('/templates/editor', methods=['GET'])
def template_editor():
    """Page to edit notification templates."""
    default_template = "Hello {{name}},\n\nYour request regarding account {{account}} at {{branch}} branch has been processed.\n\nThank you,\nLankaSecure Support"
    return render_template('editor.html', title="Template Editor", default_template=default_template)

@app.route('/templates/preview', methods=['POST'])
def template_preview():
    """
    Preview the template.
    Renders the user-supplied template with sample context data.
    """
    template_content = request.form.get('template', '')
    
    # Context variables available in the template
    # The 'flag' variable is hidden here, waiting to be discovered via SSTI
    context = {
        "name": "Ms. Dissanayake",
        "account": "****9921",
        "branch": "Kandy City Centre",
        "bank": "LankaSecure Bank",
        "flag": FLAG_SSTI 
    }

    try:
        # Rendering user input as a template
        rendered_output = render_template_string(template_content, **context)
    except Exception as e:
        rendered_output = f"Error rendering template: {str(e)}"

    return render_template('preview.html', title="Template Preview", output=rendered_output)

if __name__ == '__main__':
    # Run on all interfaces for easy access in a lab environment
    app.run(host='0.0.0.0', port=5001, debug=True)
