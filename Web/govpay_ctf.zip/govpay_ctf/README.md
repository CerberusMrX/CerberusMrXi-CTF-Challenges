MISSION BRIEFING: GovPay — Operation Blackout
=============================================

CATEGORY: Web / Exploitation
DIFFICULTY: Hard

---------------------------------------------------------------------
THE BACKSTORY
---------------------------------------------------------------------
In early 2025, the Sri Lankan government launched "GovPay," a unified digital platform for handling traffic fines and public utility fees. However, stability issues plagued the launch. Following a series of island-wide power failures and cloud outages, the operations team was forced to rush a solution.

They deployed an "Emergency Maintenance Endpoint" to manually sync backups between local nodes and the central Lanka Government Cloud.

This endpoint was shipped in a hurry. It was meant to be a temporary, admin-only tool, and as a result, it has weak security controls.

Intelligence indicates that this hidden maintenance page triggers a server-side script. We believe it is vulnerable.

---------------------------------------------------------------------
YOUR OBJECTIVE
---------------------------------------------------------------------
Your mission is to infiltrate the GovPay system. You must find a way to exploit the maintenance tool to read the secret flag located on the server at:

/srv/govpay/flag.txt

You will likely need to combine multiple vulnerabilities to achieve this.

---------------------------------------------------------------------
INSTRUCTIONS & DEPLOYMENT
---------------------------------------------------------------------
To begin your investigation, you will need to launch the local instance of the GovPay portal.

1. Open your terminal and navigate to the challenge folder.
2. Run the following command to build and start the system:
   
   docker-compose up --build

3. Once the system is running, open your web browser and access the portal at:
   
   http://localhost:8000

---------------------------------------------------------------------
INTELLIGENCE ASSETS (PROVIDED FILES)
---------------------------------------------------------------------
We have acquired the source code for the application. Use it to find the flaws.

* app/ directory: Contains the full source code of the Flask application.
* Dockerfile & docker-compose.yml: Configuration files to run the challenge locally.

Good luck, Agent. Happy hacking.
