import os
import subprocess
from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory

app = Flask(__name__)
app.secret_key = os.urandom(32)

# Hardcoded Admin Credentials
ADMIN_USER = "admin@govpay.lk"
ADMIN_PASS = "Sup3rS3cur3GovP@ssw0rd!"

# Configuration
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SCRIPT_PATH = os.path.join(BASE_DIR, "scripts", "sync_backup.sh")
OUTPUT_DIR = os.path.join(BASE_DIR, "static")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if username == ADMIN_USER and password == ADMIN_PASS:
            session['user'] = username
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid credentials", "danger")
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html')

@app.route('/admin/maintenance')
def maintenance():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('maintenance.html')

@app.route('/admin/run-maintenance', methods=['POST'])
def run_maintenance():
    # VULNERABILITY: No CSRF protection here!
    if 'user' not in session:
        return redirect(url_for('login'))
    
    target = request.form.get('target', '')
    
    if not target:
        flash("Target is required.", "warning")
        return redirect(url_for('maintenance'))

    # VULNERABILITY: Command Injection via shell=True and f-string
    # The script is called with the target parameter directly interpolated
    command = f"{SCRIPT_PATH} {target}"
    
    try:
        # Intentionally unsafe execution
        process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()
        
        if process.returncode == 0:
            flash(f"Maintenance task started for target: {target}", "success")
        else:
            flash(f"Error starting maintenance: {stderr.decode('utf-8')}", "danger")
            
    except Exception as e:
        flash(f"System error: {str(e)}", "danger")

    return redirect(url_for('maintenance'))

@app.route('/static/<path:filename>')
def custom_static(filename):
    return send_from_directory(OUTPUT_DIR, filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)
