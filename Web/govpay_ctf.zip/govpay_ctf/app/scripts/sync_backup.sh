#!/bin/bash

# GovPay Emergency Backup Sync Script
# Usage: ./sync_backup.sh <target_node>

TARGET="$1"

# Simulate some backup operations
echo "Starting backup sync for node: $TARGET"
echo "Connecting to local storage..."

# Benign operations (that would fail in this mock env but show intent)
# The vulnerability is that $TARGET is not quoted when used in the python caller's shell command construction
# But even here, if we were to use it unsafely, it would be bad.
# However, the primary injection happens in the Python `subprocess.Popen(..., shell=True)` line.
# This script just needs to exist and be executable.

# Let's pretend to do something with the target
echo "Verifying connectivity to $TARGET..."
# In a real scenario, this might be `ping -c 1 $TARGET`
# But the injection happens BEFORE this script runs, in the Python layer.
# Or, if the python layer passed it as an argument safely, we could have injection here.
# The prompt specified: "Use subprocess.Popen ... with an interpolated string and shell=True."
# So the injection is in Python. This script just receives the result (or not, if injection changes the command).

echo "Sync initiated."
exit 0
