from flask import Flask, request, render_template, render_template_string, send_file
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'press_leak_secret_2024'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/preview', methods=['POST'])
def preview():
    # SSTI Vulnerability: User input is directly rendered in template
    article_title = request.form.get('title', 'Untitled')
    article_content = request.form.get('content', '')
    author_name = request.form.get('author', 'Anonymous')
    
    # Vulnerable: Using render_template_string with user-controlled input
    template = f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Article Preview - GlobalNews Internal</title>
        <style>
            body {{ font-family: 'Georgia', serif; max-width: 800px; margin: 50px auto; background: #f5f5f5; }}
            .preview-container {{ background: white; padding: 40px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
            h1 {{ color: #2c3e50; border-bottom: 3px solid #e74c3c; padding-bottom: 10px; }}
            .meta {{ color: #7f8c8d; font-style: italic; margin: 20px 0; }}
            .content {{ line-height: 1.8; color: #34495e; }}
            .back-link {{ display: inline-block; margin-top: 30px; color: #3498db; text-decoration: none; }}
        </style>
    </head>
    <body>
        <div class="preview-container">
            <h1>{article_title}</h1>
            <div class="meta">By {author_name}</div>
            <div class="content">{article_content}</div>
            <a href="/" class="back-link">← Back to Editor</a>
        </div>
    </body>
    </html>
    '''
    
    return render_template_string(template)

@app.route('/documents')
def documents():
    return render_template('documents.html')

@app.route('/view_document', methods=['GET'])
def view_document():
    # LFI Vulnerability: No sanitization of file path
    doc_name = request.args.get('name', '')
    
    if not doc_name:
        return "No document specified", 400
    
    try:
        # Vulnerable: Direct file path construction without sanitization
        # This allows path traversal attacks like ../../../etc/passwd
        file_path = os.path.join('documents', doc_name)
        
        with open(file_path, 'r') as f:
            content = f.read()
        
        return f'''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Document Viewer - GlobalNews Internal</title>
            <style>
                body {{ font-family: 'Courier New', monospace; max-width: 900px; margin: 50px auto; background: #2c3e50; color: #ecf0f1; }}
                .doc-container {{ background: #34495e; padding: 30px; border-radius: 5px; }}
                h2 {{ color: #e74c3c; }}
                pre {{ background: #1a1a1a; padding: 20px; border-radius: 3px; overflow-x: auto; color: #2ecc71; }}
                .back-link {{ display: inline-block; margin-top: 20px; color: #3498db; text-decoration: none; }}
            </style>
        </head>
        <body>
            <div class="doc-container">
                <h2>Document: {doc_name}</h2>
                <pre>{content}</pre>
                <a href="/documents" class="back-link">← Back to Documents</a>
            </div>
        </body>
        </html>
        '''
    except Exception as e:
        return f"Error reading document: {str(e)}", 404

if __name__ == '__main__':
    # Create documents directory if it doesn't exist
    os.makedirs('documents', exist_ok=True)
    
    # Create sample documents
    with open('documents/company_policy.txt', 'w') as f:
        f.write("""GlobalNews Company Policy Document
        
Version 2.1 - Internal Use Only

1. All journalists must verify sources before publication
2. Internal systems are for authorized personnel only
3. Article drafts must be reviewed by editors
4. Confidential sources must be protected
5. System access logs are monitored

For technical support, contact: it@globalnews.internal
""")
    
    with open('documents/style_guide.txt', 'w') as f:
        f.write("""GlobalNews Editorial Style Guide

- Headlines: Title Case, max 80 characters
- Paragraphs: 3-5 sentences, clear topic sentences
- Attribution: Always cite sources
- Formatting: Use AP Style conventions
- Fact-checking: Mandatory for all claims

Remember: Accuracy over speed!
""")
    
    with open('documents/story.txt', 'w') as f:
        f.write("""The Press Leak Investigation
By Sudeepa Wanigarathna

═══════════════════════════════════════════════════════════════════════════

You've been hired as a security consultant by "GlobalNews", a major news
organization that recently experienced a data breach. An anonymous whistleblower
claims that their internal article management system has serious security flaws
that could expose confidential documents and source information.

Your mission: Investigate the GlobalNews internal system, identify the
vulnerabilities, and recover two classified flags that prove the system's
weaknesses before malicious actors can exploit them.

The clock is ticking. Journalists' sources could be at risk. Can you find
the leaks before the wrong people do?

This investigation will test your skills in web application security, including
your understanding of template injection attacks and file inclusion vulnerabilities.
You'll need to think creatively and persistently to uncover the hidden flags that
demonstrate the system's critical weaknesses.

Remember: In the world of cybersecurity, the difference between a white hat and
a black hat is authorization and intent. Always use your skills ethically and
responsibly. This controlled environment is designed for learning - never apply
these techniques to real systems without proper authorization.

Good luck, investigator. The future security of GlobalNews depends on your
findings.

═══════════════════════════════════════════════════════════════════════════

Author: Sudeepa Wanigarathna
Challenge Type: Web Exploitation (SSTI & LFI)
Difficulty: Medium
""")
    
    app.run(host='0.0.0.0', port=5000, debug=False)
