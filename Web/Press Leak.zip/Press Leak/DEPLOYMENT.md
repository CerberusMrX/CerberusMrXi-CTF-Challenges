# 🗞️ Press Leak - Deployment Guide for CTF Organizers

## Quick Start

### Prerequisites
- Docker installed (version 20.10+)
- Docker Compose installed (version 1.29+)
- Minimum 512MB RAM available
- Port 5000 available (or configure different port)

### Deploy in 3 Steps

```bash
# 1. Clone/download the challenge files
cd press-leak-ctf

# 2. Build and start the container
docker-compose up -d

# 3. Verify it's running
curl http://localhost:5000
```

The challenge is now accessible at: **http://localhost:5000**

---

## Detailed Deployment Options

### Option 1: Docker Compose (Recommended)

**Start the challenge:**
```bash
docker-compose up -d
```

**View logs:**
```bash
docker-compose logs -f
```

**Stop the challenge:**
```bash
docker-compose down
```

**Rebuild after changes:**
```bash
docker-compose up -d --build
```

### Option 2: Docker CLI

**Build the image:**
```bash
docker build -t press-leak-ctf .
```

**Run the container:**
```bash
docker run -d \
  --name press-leak \
  -p 5000:5000 \
  --restart unless-stopped \
  press-leak-ctf
```

**Stop and remove:**
```bash
docker stop press-leak
docker rm press-leak
```

---

## Configuration

### Changing the Port

**Edit `docker-compose.yml`:**
```yaml
ports:
  - "8080:5000"  # Change 8080 to your desired port
```

**Or with Docker CLI:**
```bash
docker run -d -p 8080:5000 press-leak-ctf
```

### Customizing Flags

**Before building, edit `Dockerfile`:**
```dockerfile
# Line 15-16: Change flag values
RUN echo "FLAG{your_custom_flag_1}" > /app/FLAG1.txt
RUN echo "FLAG{your_custom_flag_2}" > /etc/FLAG2.txt
```

Then rebuild:
```bash
docker-compose up -d --build
```

### Environment Variables

Currently, no environment variables are required. The application runs with default settings suitable for CTF deployment.

---

## Verification & Testing

### Health Check

```bash
# Check if container is running
docker ps | grep press-leak

# Test HTTP response
curl -I http://localhost:5000

# Expected: HTTP/1.1 200 OK
```

### Verify Flags are in Place

```bash
# Check FLAG1
docker exec press-leak cat /app/FLAG1.txt

# Check FLAG2
docker exec press-leak cat /etc/FLAG2.txt
```

### Test Vulnerabilities

**Test SSTI:**
```bash
curl -X POST http://localhost:5000/preview \
  -d "title={{ 7*7 }}&author=Test&content=Content"

# Should see "49" in response if SSTI works
```

**Test LFI:**
```bash
curl "http://localhost:5000/view_document?name=../../../etc/FLAG2.txt"

# Should return FLAG2 content
```

---

## Multi-Instance Deployment

### For CTF Platforms (Multiple Teams)

**Using Docker Compose with port ranges:**

Create `docker-compose-multi.yml`:
```yaml
version: '3.8'

services:
  team1:
    build: .
    container_name: press_leak_team1
    ports:
      - "5001:5000"
    networks:
      - ctf_network

  team2:
    build: .
    container_name: press_leak_team2
    ports:
      - "5002:5000"
    networks:
      - ctf_network

  team3:
    build: .
    container_name: press_leak_team3
    ports:
      - "5003:5000"
    networks:
      - ctf_network

networks:
  ctf_network:
    driver: bridge
```

Deploy:
```bash
docker-compose -f docker-compose-multi.yml up -d
```

### Using Scripts for Dynamic Deployment

**Create `deploy-team.sh`:**
```bash
#!/bin/bash

TEAM_ID=$1
PORT=$((5000 + TEAM_ID))

docker run -d \
  --name press-leak-team${TEAM_ID} \
  -p ${PORT}:5000 \
  --restart unless-stopped \
  press-leak-ctf

echo "Team ${TEAM_ID} deployed on port ${PORT}"
```

**Usage:**
```bash
chmod +x deploy-team.sh
./deploy-team.sh 1  # Deploys on port 5001
./deploy-team.sh 2  # Deploys on port 5002
```

---

## Monitoring & Logging

### View Real-Time Logs

```bash
docker-compose logs -f web
```

### Export Logs

```bash
docker-compose logs web > press-leak-logs.txt
```

### Monitor Resource Usage

```bash
docker stats press-leak-ctf
```

---

## Security Considerations

### Network Isolation

The challenge runs in an isolated Docker network by default. For additional security:

```yaml
# docker-compose.yml
services:
  web:
    networks:
      - ctf_network
    cap_drop:
      - ALL
    cap_add:
      - NET_BIND_SERVICE
    read_only: true
    tmpfs:
      - /tmp
```

### Firewall Rules

If exposing to the internet:

```bash
# Allow only specific IPs (example)
sudo ufw allow from 192.168.1.0/24 to any port 5000

# Or use nginx reverse proxy with rate limiting
```

### Reset Between Teams

```bash
# Complete reset
docker-compose down
docker-compose up -d --build

# This ensures fresh instances with no residual data
```

---

## Troubleshooting

### Container Won't Start

**Check logs:**
```bash
docker-compose logs web
```

**Common issues:**
- Port 5000 already in use → Change port in docker-compose.yml
- Insufficient memory → Allocate more RAM to Docker
- Permission issues → Run with sudo or fix Docker permissions

### Application Not Accessible

**Verify port binding:**
```bash
netstat -tulpn | grep 5000
```

**Test from inside container:**
```bash
docker exec press-leak curl localhost:5000
```

### Flags Not Found

**Verify flag files exist:**
```bash
docker exec press-leak ls -la /app/FLAG1.txt
docker exec press-leak ls -la /etc/FLAG2.txt
```

**If missing, rebuild:**
```bash
docker-compose down
docker-compose up -d --build
```

### SSTI/LFI Not Working

**Check Flask is using correct code:**
```bash
docker exec press-leak cat /app/app.py | grep render_template_string
```

**Verify vulnerabilities:**
```bash
# SSTI test
curl -X POST http://localhost:5000/preview \
  -d "title={{ config }}&author=Test&content=Test"

# LFI test
curl "http://localhost:5000/view_document?name=../app.py"
```

---

## Maintenance

### Update Challenge

```bash
# Pull latest changes
git pull

# Rebuild and restart
docker-compose down
docker-compose up -d --build
```

### Backup Configuration

```bash
# Backup all challenge files
tar -czf press-leak-backup.tar.gz \
  app.py templates/ Dockerfile docker-compose.yml requirements.txt
```

### Clean Up

```bash
# Remove containers and images
docker-compose down --rmi all

# Remove unused Docker resources
docker system prune -a
```

---

## Integration with CTF Platforms

### CTFd Integration

1. Create a new challenge in CTFd
2. Set challenge type: "Standard"
3. Add challenge description from README_challenge.txt
4. Add hints (Tier 1, 2, 3) with point deductions
5. Add flags:
   - FLAG1: `FLAG{t3mpl4t3_1nj3ct10n_m4st3r_2024}`
   - FLAG2: `FLAG{l0c4l_f1l3_1nclus10n_pr0_2024}`
6. Set connection info: `http://[your-server]:5000`

### PicoCTF Integration

Similar process - import challenge metadata and deploy container on infrastructure.

---

## Performance Tuning

### For High-Traffic Events

**Increase worker processes:**

Edit `app.py`:
```python
if __name__ == '__main__':
    from waitress import serve
    serve(app, host='0.0.0.0', port=5000, threads=4)
```

Update `requirements.txt`:
```
Flask==2.3.0
Werkzeug==2.3.0
waitress==2.1.2
```

### Load Balancing

Use nginx as reverse proxy:

```nginx
upstream press_leak {
    server localhost:5001;
    server localhost:5002;
    server localhost:5003;
}

server {
    listen 80;
    location / {
        proxy_pass http://press_leak;
    }
}
```

---

## Support & Contact

For issues with deployment:
1. Check troubleshooting section
2. Review Docker logs
3. Verify system requirements
4. Contact CTF organizers

---

**Version:** 1.0  
**Last Updated:** 2024  
**Tested On:** Docker 24.0+, Ubuntu 22.04, macOS Ventura, Windows 11 WSL2
