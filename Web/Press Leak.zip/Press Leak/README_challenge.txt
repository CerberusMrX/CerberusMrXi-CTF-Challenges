═══════════════════════════════════════════════════════════════════════════
                            🗞️ PRESS LEAK 🗞️
                    A Web Exploitation CTF Challenge
═══════════════════════════════════════════════════════════════════════════

📰 STORYLINE
═══════════════════════════════════════════════════════════════════════════

You've been hired as a security consultant by "GlobalNews", a major news
organization that recently experienced a data breach. An anonymous whistleblower
claims that their internal article management system has serious security flaws
that could expose confidential documents and source information.

Your mission: Investigate the GlobalNews internal system, identify the
vulnerabilities, and recover two classified flags that prove the system's
weaknesses before malicious actors can exploit them.

The clock is ticking. Journalists' sources could be at risk. Can you find
the leaks before the wrong people do?

═══════════════════════════════════════════════════════════════════════════
🎯 OBJECTIVES
═══════════════════════════════════════════════════════════════════════════

Find TWO flags hidden in the system:

  🚩 FLAG1: Accessible through a template vulnerability
  🚩 FLAG2: Accessible through a file system vulnerability

Each flag follows the format: FLAG{...}

═══════════════════════════════════════════════════════════════════════════
📊 DIFFICULTY LEVEL
═══════════════════════════════════════════════════════════════════════════

⭐⭐⭐ MEDIUM

Required Skills:
  • Understanding of web application architecture
  • Knowledge of template injection attacks
  • Familiarity with file inclusion vulnerabilities
  • Basic Python/Flask knowledge (helpful but not required)
  • Creative thinking and persistence

═══════════════════════════════════════════════════════════════════════════
🚀 GETTING STARTED
═══════════════════════════════════════════════════════════════════════════

1. Deploy the challenge:
   docker-compose up -d

2. Access the system:
   http://localhost:5000

3. Explore the application:
   - Try the Article Editor
   - Browse the Document Management System
   - Look for unusual behavior or error messages

4. Think like an attacker:
   - What user inputs are reflected in the application?
   - How does the system handle file operations?
   - Are there any filters or sanitization?

═══════════════════════════════════════════════════════════════════════════
💡 PROGRESSIVE HINTS
═══════════════════════════════════════════════════════════════════════════

┌─────────────────────────────────────────────────────────────────────────┐
│ TIER 1 HINTS - General Direction                                        │
└─────────────────────────────────────────────────────────────────────────┘

  Hint 1.1: The article preview feature processes your input in an
             interesting way. What happens if you submit special characters
             or expressions?

  Hint 1.2: The document viewer allows you to specify filenames. What if
             the file you want isn't in the documents folder?

  Hint 1.3: Flask applications often use template engines. Jinja2 has some
             powerful features that might be exploitable.

┌─────────────────────────────────────────────────────────────────────────┐
│ TIER 2 HINTS - Technical Guidance                                       │
└─────────────────────────────────────────────────────────────────────────┘

  Hint 2.1 (FLAG1): Try injecting template expressions like {{ 7*7 }} in
                     the article fields. If you see "49" in the output, you've
                     found a Server-Side Template Injection (SSTI) vulnerability.

  Hint 2.2 (FLAG1): In Jinja2, you can access Python objects and functions.
                     Research how to read files using template injection.

  Hint 2.3 (FLAG2): The document viewer constructs file paths. Can you use
                     "../" to traverse directories? Try accessing files outside
                     the documents folder.

  Hint 2.4 (FLAG2): FLAG2 is stored in a system location. Think about where
                     important files are typically stored in Linux systems.

┌─────────────────────────────────────────────────────────────────────────┐
│ TIER 3 HINTS - Almost There!                                            │
└─────────────────────────────────────────────────────────────────────────┘

  Hint 3.1 (FLAG1): FLAG1.txt is in the /app directory. Use Jinja2's
                     built-in functions to read it. Look into:
                     {{ config.__class__.__init__.__globals__ }}

  Hint 3.2 (FLAG1): You can access the 'open' function through Python's
                     built-in objects accessible via template globals.

  Hint 3.3 (FLAG2): Try: /view_document?name=../../../etc/FLAG2.txt
                     The path traversal should work if properly crafted.

═══════════════════════════════════════════════════════════════════════════
📚 LEARNING RESOURCES
═══════════════════════════════════════════════════════════════════════════

  • OWASP: Server-Side Template Injection
  • PortSwigger Web Security Academy: SSTI
  • OWASP: Path Traversal / LFI
  • Jinja2 Documentation (Template Designer)

═══════════════════════════════════════════════════════════════════════════
⚠️  RULES & ETHICS
═══════════════════════════════════════════════════════════════════════════

  ✓ This is a CONTROLLED ENVIRONMENT for learning
  ✓ Only attack the deployed Docker container
  ✓ Do NOT use these techniques on real systems without authorization
  ✓ Unauthorized access to computer systems is illegal
  ✓ Use your skills ethically and responsibly

═══════════════════════════════════════════════════════════════════════════

Good luck, and happy hacking! 🔐

═══════════════════════════════════════════════════════════════════════════
