<?php
$debug_mode = isset($_GET['debug']) && $_GET['debug'] === 'true';
$clue = 'audit_the_logs_carefully'; // Part 1 flag or passphrase for RE
if ($debug_mode) {
    // The vulnerability: Expose a hidden clue when debug=true
    header('Content-Type: text/plain');
    echo base64_encode($clue); // First flag/lead
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $feedback = $_POST['feedback'] ?? '';
    $msg = 'Thank you, agent! Your feedback will be reviewed by PayLanka cyber ops.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>PayLanka Employee Feedback</title>
  <link href="https://fonts.googleapis.com/css?family=Roboto:400,700" rel="stylesheet">
  <style>body{font-family:'Roboto',sans-serif;background:#202940;color:#eee;}.container{max-width:520px;margin:38px auto;background:rgba(255,255,255,0.06);border-radius:10px;box-shadow:0 1.5px 9px #19d4ef27;padding:28px;}h2{color:#19d4ef;}.footer{margin-top:30px;color:#aaa;}.field{border:1px solid #284be7;padding:10px 14px;font-size:16px;border-radius:3px;width:97%;resize:vertical;background:#101520;color:#e9fcfa;}.btn{background:#284be7;color:#fff;font-weight:700;padding:9px 32px;border:none;border-radius:4px;margin-top:14px;font-size:17px;transition:0.1s} .btn:hover{background:#19d4ef;color:#00182c;}</style>
</head>
<body>
<div class="container">
  <h2>Employee Feedback Portal</h2>
  <p style="color:#8be3ef;">Help PayLanka respond to cyber incidents. Anonymous field for internal use.</p>
  <?php if (isset($msg)) echo "<p style='color:#45d883;font-size:17px;'>$msg</p>"; ?>
  <form method="POST">
    <textarea class="field" name="feedback" rows="5" placeholder="Your confidential incident details..."></textarea><br>
    <button class="btn" type="submit">Submit Feedback</button>
  </form>
  <div style="margin-top:12px;font-size:15px;color:#dedede;">PayLanka Forensics Panel — <i>Debug endpoints strictly forbidden!</i></div>
  <div class="footer">Forensics Case 2025-0314 | PayLanka Cybersecurity Response</div>
</div>
</body>
</html>
