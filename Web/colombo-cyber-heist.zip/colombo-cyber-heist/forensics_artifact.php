<?php
$hint1 = "Agents, sometimes image artifacts contain data after the normal file ends—try binwalk, steghide, or even 'strings'.";
$hint2 = "Look for unexpected content after the PNG IEND marker. The final flag is embedded (not visual).";
$flag = "flag{paylanka_shadow_turtle_trace_complete}";
$solved = isset($_GET['solved']) && $_GET['solved'] === '1';
?>
<!DOCTYPE html>
<html lang="en"><head>
  <meta charset="UTF-8">
  <title>Colombo Cyber Heist - Forensics/Stego</title>
  <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
<div class="dashboard">
  <header><h1>Stage 3: Digital Forensics & Stego</h1></header>
  <div class="comic-header">Agent Chat: "A captured PNG from the incident—the network dump shows extra data after the image..."</div>
  <div class="comic-panel entry"><p>
    <strong>Artifact:</strong> <a href="assets/img/colombo_packet_artifact.png" download>Download Network Artifact (PNG)</a><br>
    <span class="hinted">(You may also analyze its metadata or run forensics with your own tools!)</span>
  </p></div>

  <div class="comic-panel">
    <p><img src="assets/img/colombo_packet_artifact.png" alt="artifact preview" style="max-width:340px;width:70vw;border-radius:8px;box-shadow:0 0 18px #45e9fa77;"><br><i>Preview: PNG network artifact (forensics mode)</i></p>
  </div>
  <?php if($solved): ?>
    <div class="comic-panel" style="background:#133e1b;">
      🎉 <strong>Case solved!</strong> You extracted the flag and completed your Colombo Cyber Heist mission.<br>
      <span class="hinted">Flag: <code><?=$flag?></code></span>
      <p style="font-size:1.16em;margin-top:14px;">Congrats, Agent! <a href="index.php" class="main-btn">Return to Dashboard</a></p>
    </div>
    <script>try{localStorage.setItem('ccheist_stage3','done')}catch(e){}</script>
  <?php else: ?>
    <form method="get" class="ascii-term" style="margin:28px 0;">
      <label for="f"><b>Flag Submission:</b></label><br>
      <input type="text" name="f" id="f" placeholder="Paste extracted flag here..." style="margin-top:6px;font-family:monospace;padding:7px;width:60vw;max-width:350px;" autocomplete="off">
      <button type="submit" class="main-btn">Validate</button>
      <?php if(isset($_GET['f'])){
        if(trim($_GET['f'])==$flag){
          echo '<input type="hidden" name="solved" value="1" />';
          echo '<script>window.location.href="?solved=1"</script>';
        } else {
          echo "<div class='comic-panel' style='background:#380c0d;'>❌ Not quite—double check your extraction method.</div>";
        }
      }
      ?>
    </form>
  <?php endif; ?>
  <div class="mission-progress-bar">
    <div class="prog-step">Web Exploit</div>
    <div class="prog-step">Reverse Engineering</div>
    <div class="prog-step active">Forensics/Stego</div>
  </div>
  <section class="agent-hints">
      <div class="agent-chat-badge">💬 Teammate (Forensics):</div>
      <div class="comic-panel" id="hint-1">Hint: <?=$hint1?></div>
      <?php if(isset($_GET['f']) && !$solved):?><div class="comic-panel" id="hint-2">Hint+: <?=$hint2?></div><?php endif; ?>
  </section>
  <footer><a href="index.php" class="pdf-link">Back to Dashboard</a></footer>
</div>
</body></html>
