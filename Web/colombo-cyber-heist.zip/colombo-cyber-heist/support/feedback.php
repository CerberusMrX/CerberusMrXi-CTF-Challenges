<?php
function show_config() {
    header('Content-Type: text/plain');
    echo <<<CONF
# PayLanka SYSTEM CONFIGURATION ARCHIVE (config.old)
# <story: This backup contains remnants of a network breach investigation>

ADMIN_DEBUG=off
SUPPORT_EMAIL=helpdesk@paylanka.lanka
PATCH_DATE=2025-03-13
SECRET_FLAG=flag{debug_portal_exposed}
REVERSE_PASS=aU5pYWxCGV9TdHVubmVsCWVfbGFBOw==
# (decoded pass is for the suspicious binary)

// archived endpoints
legacy_upload=/hidden/report_viewer.php
CONF;
}

// On ?debug=true, leak config.old
if (isset($_GET['debug']) && $_GET['debug'] === 'true') {
    show_config();
    exit;
}
$msg = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $feedback = $_POST['feedback'] ?? '';
    $msg = "Thank you, agent. All tips matter. (Check the 'old configs' for any breach traces!)";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>PayLanka Support Portal (Legacy)</title>
  <link href="https://fonts.googleapis.com/css2?family=Fira+Mono:wght@700&display=swap" rel="stylesheet">
  <style>body{background:#1a222a;color:#d7e1ea;font-family:'Fira Mono',monospace;} .container{max-width:470px;margin:48px auto;background:rgba(46,55,74,0.98);border-radius:8px;box-shadow:0 2px 9px #00eaff37;padding:24px 32px;} h2{color:#00eaff;} input,textarea{background:#222f3e;color:#e7faff;border:1.2px solid #00eaff55;padding:9px;width:100%;border-radius:5px;font-size:1em;} button{background:#00b8d6;color:#20324b;font-weight:700;border:none;border-radius:5px;padding:10px 46px;font-size:1.13em;margin-top:18px;box-shadow:0 0 8px #00eaff55;transition:.17s;} button:hover{background:#fff;color:#191f2b;} .footer{color:#aae;font-size:13px;text-align:center;margin-top:30px;} .hint{background:#20304b;font-size:14px;border-left:3px solid #00eaff99;padding:8px 13px;margin-bottom:18px;border-radius:5px;color:#b7e9ff;}</style>
</head>
<body>
<div class="container">
  <h2>PayLanka Support Portal</h2>
  <p style="color:#22eee9;">Legacy feedback system for urgent cyber issues. Some features may be outdated. <span style="color:#f4d342;">*Comics Edition*</span></p>

  <?php if ($msg) echo "<div class='hint'>\xF0\x9F\x91\xA4 $msg</div>"; ?>

  <form method="POST">
    <textarea name="feedback" rows="5" placeholder="How can we help your cyber investigation?"></textarea><br>
    <button type="submit">Submit Incident Report</button>
  </form>
  <div class="footer">Psst: <strong>Sometimes legacy portals leak <em>old config</em> files… try appending <code>?debug=true</code> to the URL.</strong></div>
</div>
</body>
</html>
