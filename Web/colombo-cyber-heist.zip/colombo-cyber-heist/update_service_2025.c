// ----------------------------------------------
// Shadow Turtle — PayLanka Cyber Heist (Comic RE)
// ----------------------------------------------
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define FLAG "flag{lab_usb_anushka}" // comic: discovered by Anushka in the lab
#define ENDPOINT "/hidden/report_viewer.php"
#define SECRET_PASS "aU5pYWxCGV9TdHVubmVsCWVfbGFBOw==" // the encoded pass (base64 of 'INialB_V_Stunnel_e_laA;')

// Prints the comic intro panel and expects the right pass
void comic_intro() {
    printf("\n----- SHADOW TURTLE USB TOOL -----\n");
    printf("     __                     __\n");
    printf("    ( o)   PAYLANKA CYBER    (o )\n");
    printf("   /---\   HEIST INCIDENT   /---\n");
    printf("  |     |      2025        |     |\n");
    printf("   \___/   #ShadowTurtle    \___/\n\n");
    printf("[Comic CTF Panel]\n\n");
}

int main() {
    char input[80];
    comic_intro();
    printf("To continue your investigation, enter the secret passphrase: ");
    fgets(input, sizeof(input), stdin);
    input[strcspn(input, "\n")] = 0;
    // base64 decode
    if (strcmp(input, "INialB_V_Stunnel_e_laA;") != 0) {
        puts("Access denied. This doesn't match the lab artifact passphrase.\n");
        return 1;
    }
    printf("\nAccess granted!\n\nComic Scene: As Anushka decrypts the USB, she uncovers a secret endpoint for the final artifact: \033[1;36m%s\033[0m\n", ENDPOINT);
    printf("\nStage Flag: %s\n", FLAG);
    printf("\nDownload the artifact and check for hidden messages!\n\n");
    return 0;
}

