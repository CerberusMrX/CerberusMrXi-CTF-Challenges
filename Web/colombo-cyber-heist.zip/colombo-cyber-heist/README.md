# 🕵️‍♂️ The Colombo Cyber Heist — Professional CTF Platform

## 📖 Mission Comic

**It was a stormy night in Colombo...** A 120M rupee cyber heist at PayLanka HQ. Shadow Turtle—a hacker crew—leaves digital traces. Your mission: trace their path across 3 stages (Web Exploitation → Reverse Engineering → Forensics/Steganography). Every clue connects to the next. Play as a Digital Forensics Investigator and uncover the truth!

## Playable Mission Flow

- **Dashboard with Comic Storyboard** (index.php)
- **Advanced Web Bug** (LFI with flawed sanitization via `path=`):
  - *Scene:* Hacker abuses encoded traversal to reach backup config
  - **Example:** `web_exploit.php?path=..%2fassets%2fsecrets%2fconfig.old.bak`
  - **Flag:** flag{debug_portal_exposed}
- **Reverse Engineering Binary** (update_service_2025.bin):
  - *Scene:* Anushka in forensics lab, uses pass (decoded from config.old)
  - **Flag:** flag{lab_usb_anushka}
  - **Reveals:** /hidden/report_viewer.php
- **Forensics/Stego Network Artifact** (hidden/report_viewer.php):
  - *Scene:* Analyst finds image with extra bytes, reveals final flag
  - **Flag:** flag{paylanka_shadow_turtle_trace_complete}

## 🚀 Quick Start (Players & Hosts)

### For Players:
1. Start the CTF server: `docker-compose up --build`
2. Visit [http://localhost:8080](http://localhost:8080) in your browser
3. Read the comic dashboard and click **"Begin Investigation"**
4. Navigate through 3 levels (comic panels unlock as you solve each one)
5. Use **Agent Hints** if you get stuck—they appear automatically or via chat!

### Recommended Tools:
- **Web Challenge:** Browser DevTools, curl, base64 decoder
- **Reverse Engineering:** Ghidra/IDA, strings, base64 decoder, Linux terminal
- **Forensics/Stego:** binwalk, steghide, zsteg, hexdump, xxd
- All challenges include in-game hints via **Agent Chat** system!

### For Hosts/Organizers:
See [Hosting Guide](#-hosting-organizers) section below for setup, customization, and scoring integration.

---

## 🏆 Hosting (Organizers)

### Setup Steps:
1. Clone/download this CTF directory
2. Run `docker-compose up --build` (or deploy to your web server/VPS)
3. Access via `http://localhost:8080` (or your server IP)
4. Players navigate through challenges, submit flags for scoring

### Customization:
- **Change Flags:** Edit `assets/data/config.old.txt` and `forensics_artifact.php`
- **Modify Hints:** Update `assets/data/README_HINTS.md` or edit inline PHP hint variables
- **Replace PNG Asset:** Swap `assets/img/colombo_packet_artifact.png` with your own steganography image (append flag text!)
- **Add More Levels:** Extend challenges by adding new PHP pages following existing patterns

### CTF Platform Integration:
- All flags are in standard format: `flag{...}` ready for CTFd, FBCTF, or custom platforms
- Flag submission is per-page; integrate with your scoring backend if needed

---

## 🎯 Solution Walkthrough (Spoilers!)

### Challenge 1 - Web Exploitation:
- URL: `http://localhost:8080/web_exploit.php?path=..%2fassets%2fsecrets%2fconfig.old.bak`
- Extract `SECRET_FLAG` from the backup config
- **Flag:** `flag{debug_portal_exposed}`

### Challenge 2 - Reverse Engineering:
- Download `assets/bin/update_service_2025.bin` (or compile from `.c` source)
- Base64 decode `REVERSE_PASS` from config.old: `INialB_V_Stunnel_e_laA;`
- Run binary with this passphrase OR submit directly on the web page
- **Flag:** `flag{lab_usb_anushka}`

### Challenge 3 - Forensics/Steganography:
- Download `assets/img/colombo_packet_artifact.png`
- Use binwalk/steghide to extract hidden text appended after PNG EOF
- **Flag:** `flag{paylanka_shadow_turtle_trace_complete}`

---

## 📁 Challenge File Assets

**Project Structure:**
```
colombo-cyber-heist/
├── index.php                          # Main dashboard/comic story
├── web_exploit.php                     # Stage 1: Web challenge
├── reverse_binary_challenge.php        # Stage 2: RE challenge
├── forensics_artifact.php              # Stage 3: Stego/forensics
├── assets/
│   ├── css/styles.css                 # Professional UI theme
│   ├── data/                          # Flags, configs, hints
│   │   ├── config.txt
│   │   ├── config.old.txt
│   │   └── README_HINTS.md
│   ├── bin/                           # Binary challenge
│   │   └── update_service_2025.c
│   └── img/                           # Forensics PNG
│       └── colombo_packet_artifact.png
├── Dockerfile
├── docker-compose.yml
└── README.md
```

**For more customization details**, see `assets/data/README_HINTS.md` for agent hint system documentation!

---

Powered by **ShadowTurtle Labs** | Stay safe, stay observant! 🕵️‍♂️🔒
