<?php
if (isset($_GET['download'])) {
    header('Content-Type: image/png');
    header('Content-Disposition: inline; filename="report_viewer.png"');
    readfile('report_viewer.png');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Shadow Turtle Network Artifact</title>
  <link href="https://fonts.googleapis.com/css?family=Oswald:500&display=swap" rel="stylesheet">
  <style>body{background:#151d2d;font-family:'Oswald',sans-serif;color:#e0f7fa;} .container{max-width:460px;margin:48px auto;background:rgba(53,92,153,0.14);border-radius:11px;box-shadow:0 2px 14px #00eaff40;padding:30px 34px;}h2{color:#00eaff;} .img-preview{border-radius:7px;margin-bottom:10px;border:1.5px solid #00d5ef;box-shadow:0 0 10px #39e6ce99;} .footer{margin-top:25px;color:#96aac7;} a.btn{display:inline-block;margin:16px 0 0 0;padding:11px 26px;background:#00eaff;color:#091f3a;font-weight:700;text-decoration:none;font-size:17px;border-radius:5px;box-shadow:0 0 9px #7bf9c644;}a.btn:hover{background:#39e6ce;}</style>
</head>
<body>
<div class="container">
  <h2>Shadow Turtle Artifact</h2>
  <img class="img-preview" src="report_viewer.php?download=1" alt="Artifact PNG" width="405">
  <p style="margin:17px 0 0 0;color:#39e6ce;font-size:18px;">A network packet carried an image — but the transfer had <b>extra bytes</b> after the file ended. Could there be a message hidden after EOF?</p>
  <a class="btn" href="report_viewer.php?download=1">Download Artifact PNG</a>
  <div class="footer">"ShadowTurtle was here. Operation complete." <br>Forensics Panel, Colombo Cyber Heist</div>
</div>
</body>
</html>
