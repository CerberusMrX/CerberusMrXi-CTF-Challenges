<?php
if (isset($_GET['download'])) {
    // Serve the PNG image directly
    header('Content-Type: image/png');
    header('Content-Disposition: inline; filename="report_viewer.png"');
    readfile('report_viewer.png');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Finance Report Viewer - PayLanka</title>
  <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&display=swap" rel="stylesheet">
  <style>body{background:#1b212b;font-family:'Roboto',sans-serif;color:#e0fbfa;} .container{max-width:540px;margin:44px auto;background:rgba(34,79,164,0.085);border-radius:11px;box-shadow:0 3px 13px #10bee732;padding:30px 34px;}h2{color:#10bee7;}.footer{margin-top:28px;color:#aaa;}.img-preview{border-radius:7px;margin-bottom:10px;border:1.5px solid #114bab;box-shadow:0 0 7px #10bee733;}a.download-btn{display:inline-block;margin:13px 0 0 0;padding:10px 26px;background:#19d4ef;color:#192232;font-weight:700;text-decoration:none;font-size:17px;border-radius:5px;box-shadow:0 0 7px #50e3c227;}a.download-btn:hover{background:#50e3c2;}</style>
</head>
<body>
<div class="container">
  <h2>2025 Q1 Financial Report</h2>
  <img class="img-preview" src="report_viewer.php?download=1" alt="Q1 Report PNG" width="460">
  <p style="margin:20px 0;color:#88ebf5;font-size:17px;">Analysts may want to examine every digital artifact. Forensic tools can reveal more than meets the eye.<br>
    <b>Hint:</b> Modern stego techniques hide data in plain sight. Tools like <code>binwalk</code>, <code>zsteg</code>, or <code>steghide</code> are often helpful.<br>
    <a class="download-btn" href="report_viewer.php?download=1">Download PNG Artifact</a></p>
  <div class="footer">PayLanka Cybersecurity Report Portal, Q1 2025</div>
</div>
</body>
</html>
