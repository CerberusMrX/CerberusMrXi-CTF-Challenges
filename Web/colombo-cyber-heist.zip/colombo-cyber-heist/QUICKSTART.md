# 🚀 Quick Start Guide - Colombo Cyber Heist CTF

## ✅ All Files Verified & Ready!

Your CTF is **100% complete** and ready to run. All components are in place:
- ✅ Comic storyboard landing page
- ✅ 3 challenge levels (Web, Reverse, Forensics)
- ✅ All flag files created and embedded
- ✅ Binary compiled and ready
- ✅ PNG artifact with hidden flag
- ✅ Professional UI/UX styling
- ✅ Docker configuration

---

## 🎮 How to Launch Your CTF

### Option 1: Using Docker (Recommended)
```bash
# Make sure you're in the colombo-cyber-heist directory
cd /home/cerberusmrxi/colombo-cyber-heist

# If you get permission errors, use sudo:
sudo docker-compose up --build

# Or add yourself to docker group (one-time setup):
sudo usermod -aG docker $USER
# Then log out and back in, then run:
docker-compose up --build
```

### Option 2: Using PHP Built-in Server (No Docker)
```bash
cd /home/cerberusmrxi/colombo-cyber-heist
php -S localhost:8080
```

---

## 🌐 Access Your CTF

Once running, open your browser and go to:
**http://localhost:8080**

---

## 🎯 Test Each Challenge

### Stage 1 - Web Exploitation:
- Visit: `http://localhost:8080/web_exploit.php?path=..%2fassets%2fsecrets%2fconfig.old.bak`
- **Expected:** Backup config reveals: `flag{debug_portal_exposed}`

### Stage 2 - Reverse Engineering:
- Visit: `http://localhost:8080/reverse_binary_challenge.php`
- Download binary or submit password: `INialB_V_Stunnel_e_laA;`
- **Expected:** Flag appears: `flag{lab_usb_anushka}`

### Stage 3 - Forensics:
- Visit: `http://localhost:8080/forensics_artifact.php`
- Download PNG and extract flag with: `tail -c 50 assets/img/colombo_packet_artifact.png`
- **Expected:** Flag appears: `flag{paylanka_shadow_turtle_trace_complete}`

---

## ✅ Verification Checklist

Everything is ready:
- ✅ All PHP files exist and have no syntax errors
- ✅ CSS styling is complete
- ✅ Config files are in place (config.txt, config.old.txt)
- ✅ Binary compiled (16KB executable)
- ✅ PNG created with embedded flag (132 bytes)
- ✅ All flags properly embedded
- ✅ README documentation complete

---

## 🐛 Troubleshooting

**Permission Denied Error:**
- Run with: `sudo docker-compose up --build`
- Or add user to docker group (see above)

**Port Already in Use:**
- Change port in `docker-compose.yml` from 8080 to another port
- Or kill existing process: `sudo lsof -ti:8080 | xargs sudo kill`

**Container Won't Start:**
- Check logs: `docker-compose logs`
- Rebuild: `docker-compose down && docker-compose up --build`

---

**Your CTF is professional, complete, and ready for players!** 🎉

