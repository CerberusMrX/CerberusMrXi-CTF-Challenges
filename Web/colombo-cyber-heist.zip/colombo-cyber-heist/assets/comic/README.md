# 📖 Comic Image Instructions

## Add Your Comic Image

To add your story-based comic image to the main landing page:

1. **Place your comic image file** in this directory as: `main_comic.png`

2. **Recommended specifications:**
   - **Format:** PNG (preferred), JPG, or WEBP
   - **Dimensions:** 1200x800px or similar wide format
   - **Aspect ratio:** 16:10 or 3:2 works best
   - **File size:** Under 2MB for fast loading

3. **Supported formats:**
   - PNG (best quality, transparency support)
   - JPG (smaller file size)
   - WEBP (modern, best compression)

## How It Works

The landing page will automatically:
- Display your image in a large, prominent container
- Show a friendly placeholder if the image is missing
- Scale responsively on mobile devices

## Example

If your comic image is called `colombo_story.png`:

```bash
# Copy your image to the comic directory
cp /path/to/your/colombo_story.png assets/comic/main_comic.png
```

The index page will automatically display it!

---

**Need help?** Check the main README.md for full documentation.

