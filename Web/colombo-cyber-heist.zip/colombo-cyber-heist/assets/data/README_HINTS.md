# Agent Hints System (Colombo Cyber Heist)

- All major challenge levels have in-page agent hints (comic chat style)
- Hints are progressive: first is subtle, second (shown on attempt or after initial try) is more explicit
- In the code, adjust the variables $hint1/$hint2 (PHP) or later use hints.json for larger events
- Agents: Anushka (web, RE hints), Teammate (forensics), or any new persona you wish
- For more levels, add further hints as needed: just update in the relevant PHP as `comic-panel`, or tie into a future JS/XHR hint loader
- Add new agents/character badges in CSS+HTML as more levels or characters are created
