<?php 
// Level 2 - Agent chat and ascii binary challenge
$flag="flag{lab_usb_anushka}";
$correct_pass="INialB_V_Stunnel_e_laA;";
$hint1="Take a close look at the config or backup from Stage 1. Something there is base64...";
$hint2="Decode the pass, inspect props in strings or ASCII. Input it below for the binary to reveal the next clue.";
$res_msg="";
$pass = $_POST['pass'] ?? '';
$solved = false;
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if(trim($pass)===$correct_pass) {
      $solved = true;
      $res_msg = "<div class='comic-panel' style='background:#114baa;'>Access granted!<br>Great work, Agent. <strong>Hidden endpoint:</strong> <code>/forensics_artifact.php</code><br><span class='hinted'>Proceed for the last flag!</span></div>";
    } else {
      $res_msg = "<div class='comic-panel' style='background:#380c0d;'>❌ Access denied. Try again or revisit the config file.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en"><head>
  <meta charset="UTF-8">
  <title>Colombo Cyber Heist - Reverse Engineering</title>
  <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
<div class="dashboard">
  <header><h1>Stage 2: Reverse Engineering</h1></header>
  <div class="comic-header">Agent Chat: "The USB binary from the van may require a config passphrase—something from Stage 1?"</div>
  <div class="comic-panel entry"><p>
    <strong>USB Evidence:</strong> <a href="assets/bin/update_service_2025.bin" download>Download update_service_2025.bin</a><br>
    <span class="hinted">(Run with <code>./update_service_2025.bin</code> after chmod, or just enter the pass below.)</span>
  </p></div>

  <form method="post" class="ascii-term" style="margin:30px 0 8px 0;">
    <label for="pass">Enter binary passphrase:</label><br>
    <input type="text" name="pass" id="pass" placeholder="Copy from decoded config base64..." autocomplete="off" style="margin-top:6px;font-family:monospace;padding:7px;width:50vw;max-width:350px;" />
    <button type="submit" class="main-btn">Submit</button>
  </form>
  <?=$res_msg?>
  <?php if($solved): ?><div class="comic-panel" style="background:#133e1b;">
        🎉 <b>Final flag awaits in network artifact analysis!</b><br>
        <a href="forensics_artifact.php" class="main-btn">Go to Forensic Artifact ➔</a>
        <div class="hinted">Hint: Sometimes images carry more than pixels...</div></div>
  <script>try{localStorage.setItem('ccheist_stage2','done')}catch(e){}</script>
  <?php endif; ?>
  <div class="mission-progress-bar">
    <div class="prog-step">Web Exploit</div>
    <div class="prog-step active">Reverse Engineering</div>
    <div class="prog-step">Forensics/Stego</div>
  </div>
  <section class="agent-hints">
      <div class="agent-chat-badge">💬 Anushka (Agent):</div>
      <div class="comic-panel" id="hint-1">Stage Hint: <?=$hint1?></div>
      <?php if($pass&&!$solved):?><div class="comic-panel" id="hint-2">Hint+: <?=$hint2?></div><?php endif; ?>
  </section>
  <footer><a href="index.php" class="pdf-link">Back to Dashboard</a></footer>
</div>
</body>
</html>
